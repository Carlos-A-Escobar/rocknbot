import json
import re
import os
import lancedb
import copy
import openai
import tiktoken
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext, Document
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings, Document
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.node_parser import MarkdownNodeParser, SentenceSplitter
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
import nest_asyncio

os.environ["OPENAI_API_KEY"] = '<YOUR_OPENAI_API_KEY_HERE>'
OPENAI_API_KEY = '<YOUR_OPENAI_API_KEY_HERE>'
# with open('qa_pairs.json', 'r') as file:
#     data = json.load(file)

# with open('positive_conversations.md', "a+", encoding="utf-8") as file_to_write:
#     for i, entry in enumerate(data, start=1):
#         question = entry['question']
#         answer = entry['answer']
#         chunk_content = (
#                 f"# Question/Answer Pair {str(i)}\n\nQuestion: {question}\nAnswer: {answer}\n\n\n"
#             )
#         file_to_write.write(chunk_content)

# Read the content of the markdown file
with open('iddm_qa_pairs.md', 'r', encoding='utf-8') as file:
    content = file.read()

# Split the content by the delimiter
qa_pairs = content.split('# Question/Answer Pair')

# Remove any leading/trailing whitespace and filter out any empty strings
qa_pairs = [pair.strip() for pair in qa_pairs if pair.strip()]

# Extract question and answer pairs
documents = []
qa_pattern = re.compile(r'Question:\s*(.*?)\nAnswer:\s*(.*)', re.DOTALL)

for pair in qa_pairs:
    match = qa_pattern.search(pair)
    if match:
        question = match.group(1).strip()
        answer = match.group(2).strip()
        document = Document(text=f"Question: {question}\nAnswer: {answer}")
        documents.append(document)

splitter = SentenceSplitter(chunk_size=10000)

nodes = splitter.get_nodes_from_documents(documents=documents, show_progress=True)
print(len(documents))
print(len(nodes))

Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")

vector_store = LanceDBVectorStore(uri='lancedb', table_name='IDDM_QA_PAIRS', query_type='hybrid')
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex(nodes=nodes, storage_context=storage_context)

# db = lancedb.connect("lancedb")
# table = db.open_table("IDDM_QA_PAIRS")
# vector_store2 = LanceDBVectorStore.from_table(table)
# index2 = VectorStoreIndex.from_vector_store(vector_store=vector_store2)
# retriever = index2.as_retriever(similarity_top_k=30)

# retrieved_nodes = retriever.retrieve("what is the unit of the ETIME column?")

# print('done')

# for doc in documents:
#     for label in metadata:
#         doc.metadata[label] = metadata[label]

# nodes = pipeline.run(documents=documents, in_place=False, show_progress=True)
# all_nodes.extend(nodes)

# Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")

# vector_store = LanceDBVectorStore(uri='lancedb', table_name='IDDM', query_type='hybrid')
# storage_context = StorageContext.from_defaults(vector_store=vector_store)
# index = VectorStoreIndex(nodes=all_nodes, storage_context=storage_context)