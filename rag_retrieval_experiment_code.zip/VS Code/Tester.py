import os
import json
import lancedb
import time
import nest_asyncio
import numpy as np
from openai import OpenAI
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.core import StorageContext
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from llama_index.core.vector_stores import MetadataFilter, MetadataFilters, FilterOperator

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
nest_asyncio.apply()

QA_SYSTEM_PROMPT = """
    You are an expert Q&A system that is trusted around the world.\n
    Always answer the query using the provided context information, 
    and not prior knowledge.\n
    Response should be concise. If it can be answered in one sentence, 
    then it should be answered in one sentence.\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.\n
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

QUERY_EXPANSION_PROMPT = """
You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.
Your task is to generate five different versions of the given user question to retrieve relevant documents from a vector database. 
By generating multiple perspectives on the user question, your goal is to help the user overcome some of the limitations of the distance-based similarity search. 
Provide these alternative questions seperated by a new line. DO NOT number or hyphenate the questions. DO NOT use any special characters in your response.
"""

base_dir = 'synthetic_data_new'
sub_dirs = ['hierarchical_RL', 'sentence_RL', 'universal_RL']
file_paths = []

for sub_dir in sub_dirs:
    dir_path = os.path.join(base_dir, sub_dir)
    for file_name in os.listdir(dir_path):
        file_path = os.path.join(dir_path, file_name)
        file_paths.append(file_path)

class Tester:
    def __init__(self, result_name, embed_model, table_name, file_path, auto_merging, storage_path = None):
        self.result_name = result_name
        self.embed_model = embed_model
        self.table_name = table_name
        self.file_path = file_path
        self.auto_merging = auto_merging
        self.storage_path = storage_path
        self.reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
        self.reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)
        self.client = OpenAI()

    def process_json_file(self):
        # Setting up API key and initializing embeddings
        db = lancedb.connect("./lancedb_new")
        Settings.embed_model = self.embed_model
        table = db.open_table(self.table_name)
        vector_store = LanceDBVectorStore.from_table(table)
        index = VectorStoreIndex.from_vector_store(vector_store)
        retriever = index.as_retriever(similarity_top_k=100)

        rank = 0
        reciprocal_rank = 0
        num_questions = 0
        ndcg_5 = 0
        ndcg_10 = 0
        ndcg_20 = 0
        map_5 = 0
        map_10 = 0
        map_20 = 0

        # Load the JSON data from the file
        with open(self.file_path, 'r') as file:
            bank = json.load(file)

        total_time = 0
        # Process each question in the JSON data
        for index, data in enumerate(bank):
            if 'input' not in data or 'source_file' not in data:
                continue

            ## FIX BUG, QUESTION IS NOT A STRING, SPECIAL CHARACTERS
            question = data['input']
            id = data['source_file']
            
            start_time = time.time()
            # nodes = retriever.retrieve(question)
            nodes = self.get_nodes(retriever, question)
            end_time = time.time()
            total_time += (end_time - start_time)
            if nodes:
                # Find the rank of the correct node
                for i, node in enumerate(nodes):
                    if node.id_ == id:
                        num_questions += 1
                        this_rank = i + 1
                        rank += this_rank
                        reciprocal_rank += 1 / this_rank
                        print(f"Rank: {this_rank}, Node ID: {id}, Question Number: {index + 1}")

                        ap = 1
                        ndcg = (1.0 / np.log2(this_rank + 1))

                        if this_rank <= 20:
                            map_20 += ap
                            ndcg_20 += ndcg
                        if this_rank <= 10:
                            map_10 += ap
                            ndcg_10 += ndcg
                        if this_rank <= 5:
                            map_5 += ap
                            ndcg_5 += ndcg
                        break

        # Calculate the global average rank and average reciprocal rank
        print("rank: " + str(rank))
        print("reciprocal rank: " + str(reciprocal_rank))
        print("number of questions: " + str(num_questions))
        avg_rank = rank / num_questions if num_questions > 0 else 0
        avg_reciprocal_rank = reciprocal_rank / num_questions if num_questions > 0 else 0

        map_5 = (map_5 / num_questions)
        map_10 = (map_10 / num_questions)
        map_20 = (map_20 / num_questions)
        ndcg_5 = (ndcg_5 / num_questions)
        ndcg_10 = (ndcg_10 / num_questions)
        ndcg_20 = (ndcg_20 / num_questions)

        # Add the global averages to the JSON data
        bank.append({
            self.result_name + "_Average_Rank": avg_rank,
            self.result_name + "_Reciprocal_Rank": avg_reciprocal_rank,
            self.result_name + "_Time_Elapsed": total_time,
            self.result_name + "_MAP@5": map_5,
            self.result_name + "_MAP@10": map_10,
            self.result_name + "_MAP@20": map_20,
            self.result_name + "_NDCG@5": ndcg_5,
            self.result_name + "_NDCG@10": ndcg_10,
            self.result_name + "_NDCG@20": ndcg_20
        })    

        with open(self.file_path, 'w') as file:
            json.dump(bank, file, indent=4)

    def runMetrics(self):
        
        metrics = []
        common_params = {
            "threshold": 0.7,
            "model": "gpt-4o",
            "include_reason": False
        }

        answer_relevancy = AnswerRelevancyMetric(
            **common_params
        )

        contextual_precision = ContextualPrecisionMetric(
            **common_params
        )

        contextual_recall = ContextualRecallMetric(
            **common_params
        )

        contextual_relevancy = ContextualRelevancyMetric(
            **common_params
        )

        # hallucination = HallucinationMetric(
        #     **common_params
        # )

        metrics.append(answer_relevancy)
        metrics.append(contextual_precision)
        metrics.append(contextual_recall)
        metrics.append(contextual_relevancy)
        # metrics.append(hallucination)

        num_questions = 0
        answer_relevancy_score = 0
        contextual_precision_score = 0
        contextual_recall_score = 0
        contextual_relevancy_score = 0

        with open(self.file_path, 'r') as file:
            data = json.load(file)
        
        for entry in data:
            if 'expected_output' in entry:
                num_questions += 1
                print(num_questions)
                test_case = LLMTestCase(
                    input=entry['input'],
                    actual_output=entry[self.table_name + '_output'],
                    expected_output=entry['expected_output'],
                    retrieval_context=[entry[self.table_name + '_retrieval_context']]
                )
                scores = []
                for metric in metrics:
                    try:
                        metric.measure(test_case)
                        scores.append(metric.score)
                    except Exception as e:
                        print(f"Exception while measuring metric {metric.__class__.__name__}: {e}")
                        continue
                    
                try:
                    answer_relevancy_score += scores[0]
                    contextual_precision_score += scores[1]
                    contextual_recall_score += scores[2]
                    contextual_relevancy_score += scores[3]
                except Exception as e:
                    print(f"Exception while measuring metric {metric.__class__.__name__}: {e}")
                    continue
        
        avg_answer_relevancy = answer_relevancy_score / num_questions
        avg_contextual_precision = contextual_precision_score / num_questions
        avg_contextual_recall = contextual_recall_score / num_questions
        avg_contextual_relevancy = contextual_relevancy_score / num_questions

        data.append({
            self.table_name + " Average Answer Relevancy": avg_answer_relevancy,
            self.table_name + " Average Contextual Precision": avg_contextual_precision,
            self.table_name + " Average Contextual Recall": avg_contextual_recall,
            self.table_name + " Average Contextual Relevancy": avg_contextual_relevancy
        })
            

        with open(self.file_path, 'w') as file:
            json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation

    def generate_responses(self):
        db = lancedb.connect("./lancedb_new")
        Settings.embed_model = self.embed_model
        table = db.open_table(self.table_name)
        vector_store = LanceDBVectorStore.from_table(table)
        index = VectorStoreIndex.from_vector_store(vector_store)

        if self.auto_merging and self.storage_path is not None:
            storage_context = StorageContext.from_defaults(persist_dir=self.storage_path)
            base_retriever = index.as_retriever(similarity_top_k=20)
            retriever = AutoMergingRetriever(vector_retriever=base_retriever, storage_context=storage_context)
        else:
            retriever = index.as_retriever(similarity_top_k=5)

        with open(self.file_path, 'r') as file:
            question_num = 1
            data = json.load(file)
            for entry in data:
                print(question_num)
                question_num += 1
                if 'input' in entry:
                    question = entry['input']
                    try:
                        nodes = self.get_nodes(retriever, question)[:2]
                        chunks = ""
                        for node in nodes:
                            chunks += node.text
                            # chunks += "\n\n"
                        entry[self.table_name + '_retrieval_context'] = chunks
                        prompt = QA_USER_PROMPT.format(context_str=chunks, query_str=question)
                        response = self.client.chat.completions.create(
                            model="gpt-4o",
                            messages=[
                                {"role": "system", "content": QA_SYSTEM_PROMPT},
                                {"role": "user", "content": prompt}
                            ]
                        )
                        entry[self.table_name + "_output"] = response.choices[0].message.content
                    except Exception as e:
                        print("bad things happened with the following question: " + question)
                        continue

        with open(self.file_path, 'w') as file:
            json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation

    def get_nodes(self, retriever, question):
        nodes = retriever.retrieve(question)

        first_half = nodes[:40]
        second_half = nodes[40:]
        reranked_nodes = self.reranker.postprocess_nodes(first_half, query_str=question)

        split1 = reranked_nodes[:5]
        split2 = reranked_nodes[5:]
        reranked_nodes2 = self.reranker2.postprocess_nodes(split1, query_str=question)

        combined_nodes = reranked_nodes2 + split2
        final_nodes = combined_nodes + second_half
        # final_nodes = reranked_nodes + second_half
        return final_nodes
    
    
    def _openai_generate_response(self, system_prompt, model, question=None, reference=None, max_tokens=None, user_prompt=None):
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        if user_prompt is None:
            if question is not None:
                messages.append({"role": "user", "content": f"[Question]: {question}"})
            if reference is not None:
                messages.append({"role": "user", "content": f"[Reference text]: {reference}"})
        else:
            messages.append({"role": "user", "content": f"{user_prompt}"})
            
        params = {
            "model": model,
            "messages": messages
        }
        
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        
        response = self.client.chat.completions.create(**params)
        result = response.choices[0].message.content
        return result
        

auto_merging = False   
# auto_merging = True
# file_path = file_paths[0] # Hierahical RL
# file_path = file_paths[1] # Sentence RL
file_path = file_paths[2] # Universal RL
# file_path = file_paths[3] # Hierarchical Squad


result_name = "OpenAI"
embed_model = OpenAIEmbedding(model="text-embedding-3-large")
# table_name = "hierarchical_OpenAI_RL"
table_name = "sentence_OpenAI_RL"
storage_path = "./storage_new/OpenAI_RL"

# result_name = "BGE"
# embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en-v1.5")
# table_name = "hierarchical_BGE_RL"
# storage_path = "./storage_new/BGE_RL"

testing_obj = Tester(result_name, embed_model, table_name, file_path, auto_merging, storage_path)
# testing_obj.process_json_file()
# testing_obj.generate_responses()
testing_obj.runMetrics()