import os
import re
import dsp
import json
import dspy
import time
import lancedb
import pandas as pd
import dspy.datasets
import dspy.evaluate
import dspy.signatures
from dsp.utils.metrics import f1_score
from dsp.utils import deduplicate
from dspy import Signature, InputField, OutputField, Module, Example, Predict, Prediction
from dspy.teleprompt import BootstrapFewShot, BootstrapFewShotWithRandomSearch
from dspy.evaluate import Evaluate
from openai import OpenAI
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings, StorageContext
from llama_index.core.evaluation import SemanticSimilarityEvaluator
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from llama_index.embeddings.openai import OpenAIEmbedding

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
client = OpenAI()

db = lancedb.connect("./lancedb_final")
table = db.open_table("docs")
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)
reranker = SentenceTransformerRerank(top_n=30, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
retriever = index.as_retriever(similarity_top_k=30)

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information and without the use of prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.
    2. Avoid statements like 'Based on the context, ...' or 'The context information ...' or anything along those lines.
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Answer ALL parts of the user's query.ss
    5. Do not justify your answers.
    6. Do not restate questions or suggestions in your answer.
    7. Do not include extraneous symbols, tags, or prefixes.
    8. Do not add seemingly useless information once you have successfully answered the user's query.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ----------------------------------------------------\n
    {context_str}\n
    ----------------------------------------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

dataset = []
with open('my_qa_pairs.json', 'r') as file:
    data = json.load(file)
for entry in data:
    question = entry['question']
    answer = entry['answer']
    dataset.append(dspy.Example(question=question, answer=answer).with_inputs("question"))

trainset = dataset[:15]
testset = dataset[15:]
# trainset = []
# df = pd.read_excel("./good_results/training.xlsx")
# questions = df['question'].to_list()
# answers = df['ground_truth'].to_list()
# tuple_list = zip(questions, answers)
# for item in tuple_list:
#     trainset.append(dspy.Example(question=item[0], answer=item[1]).with_inputs("question"))


def search(question):
    question = re.sub(r'[\"]', "'", question)
    question = re.sub('[^0-9a-zA-Z?. \'_#=]+', '', question)
    child_nodes = retriever.retrieve(question)
    cross_nodes = reranker.postprocess_nodes(child_nodes, query_str=question)[:5]
    return [node.text for node in cross_nodes]


turbo = dspy.OpenAI(model='gpt-3.5-turbo', max_tokens=1000, model_type='chat')
dspy.settings.configure(lm=turbo)
evaluator = SemanticSimilarityEvaluator(similarity_threshold=0.9)


def validate_context_and_answer(example, pred, trace=None):
    score = evaluator.evaluate(response=pred.answer, reference=example.answer).score
    # score = f1_score(
    #         pred.answer,
    #         example.answer
    #     )
    if trace is None:
        return score
    result = score >= 0.93
    # if result == False:
    #     print(f"Question: {example._store.get('question')}")
    #     print(f"Ground Truth: {example._store.get('answer')}")
    #     print(f"Generated Answer: {pred._store.get('answer')}")
    return result


class GenerateSearchQuery(dspy.Signature):
    """Write a simple search query that will help answer a complex question."""

    context = dspy.InputField(desc="may contain relevant facts")
    question = dspy.InputField()
    query = dspy.OutputField()


class GenerateAnswer(Signature):
    QA_SYSTEM_PROMPT
    context = InputField(desc="may contain relevant information")
    question = InputField()
    answer = dspy.OutputField()


class RAG(dspy.Module):
    def __init__(self):
        super().__init__()
        self.generate_answer = dspy.ChainOfThought(GenerateAnswer)

    def forward(self, question):
        context = search(question)
        prediction = self.generate_answer(context=context, question=question)
        return dspy.Prediction(context=context, answer=prediction.answer)


class SimplifiedBaleen(dspy.Module):
    def __init__(self, max_hops=2):
        super().__init__()

        self.generate_query = [dspy.ChainOfThought(GenerateSearchQuery) for _ in range(max_hops)]
        self.generate_answer = dspy.ChainOfThought(GenerateAnswer)
        self.max_hops = max_hops
    
    def forward(self, question):
        context = []
        
        for hop in range(self.max_hops):
            query = self.generate_query[hop](context=context, question=question).query.strip('"')
            passages = search(query)
            context = deduplicate(context + passages)

        pred = self.generate_answer(context=context, question=question)
        return dspy.Prediction(context=context, answer=pred.answer)



multihop = SimplifiedBaleen()
teleprompter = BootstrapFewShotWithRandomSearch(metric=validate_context_and_answer, max_labeled_demos=4, num_candidate_programs=3, stop_at_score=100, num_threads=12)
compiled_rag = teleprompter.compile(multihop, trainset=trainset)
compiled_rag.save("dummy-cot.json")
# multihop.load("multihop-cot.json")

# cot_fewshot.load("demos2.json")
# evaluate_validationset_func = Evaluate(devset=testset, num_threads=1, display_progress=True, display_table=5)
# metric = validate_context_and_answer
# score = evaluate_validationset_func(compiled_rag, metric=metric)
# print(score)
# cot_fewshot.load("demos.json")
# pred2 = cot_fewshot("What are the two steps involved in identification and credential checking during the authentication process in an LDAP client?")

# multihop_fewshot = SimplifiedBaleen()
# teleprompter2 = BootstrapFewShot(metric=validate_context_and_answer)
# compiled_baleen = teleprompter2.compile(multihop_fewshot, teacher=SimplifiedBaleen(), trainset=trainset)
# compiled_baleen.save("multihop-demos.json")
# multihop_fewshot.load("multihop-demos.json")
# pred3 = multihop_fewshot("What are the two steps involved in identification and credential checking during the authentication process in an LDAP client?")



df = pd.read_excel("good_results/testing_updated.xlsx")

generated_answers = []
context = []
st1 = time.time()
for i, question in enumerate(df['question'], start=1):
    try:
        print(str(i) + "/" + str(len(df['question'])))
        pred = multihop(question)

        generated_answers.append(pred.answer)
    except Exception as e:
        print(e)
        print("BAD STUFF AT QUESTION: " + str(i))
        context.append("bad bad bad")
        generated_answers.append("bad bad bad")
et1 = time.time() - st1
time_taken = et1 / len(df['question'])
print("AVERAGE TIME PER QUESTION: " + str(time_taken))
df['answer_dspy_multihop'] = generated_answers
# df['context_dspy2'] = pd.Series(context)

df.to_excel("good_results/testing_updated.xlsx", index=False)