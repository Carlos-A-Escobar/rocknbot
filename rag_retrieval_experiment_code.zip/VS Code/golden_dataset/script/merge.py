import os

# Define the directory containing the Markdown files
directory = '/home/caes27/VS Code/golden_dataset/conversations'

# Define the output file
output_file = '/home/caes27/VS Code/golden_dataset/combined.md'

# Get a list of all Markdown files in the directory
md_files = [f for f in os.listdir(directory) if f.endswith('.md')]

# Sort the files (optional)
md_files.sort()

# Open the output file in write mode
with open(output_file, 'w') as outfile:
    for md_file in md_files:
        # Open each Markdown file in read mode
        with open(os.path.join(directory, md_file), 'r', encoding='utf-8') as infile:
            # Write the content of each file into the output file
            outfile.write(infile.read())
            # Optionally, add a separator between files
            outfile.write('\n\n')

print("Files have been successfully combined into combined.md")