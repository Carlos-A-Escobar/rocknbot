import json

with open('golden_dataset/golden.md', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Initialize variables
qa_pairs = []
current_question = None
current_answer = None
reading_question = False

# Process each line in the file
for line in lines:
    if line.startswith('# Question/Answer Pair '):
        # If we were reading an answer, save the previous question-answer pair
        if current_question is not None and current_answer is not None:
            qa_pairs.append({
                "question": current_question.strip(),
                "answer": current_answer.strip()
            })
        
        # Start reading a new question
        current_question = None
        current_answer = None
        reading_question = False
    elif line.startswith('Question:'):
        # Start reading a question
        current_question = line[len('Question:'):].strip()
        reading_question = True
    elif line.startswith('Answer:'):
        # Start reading an answer
        current_answer = line[len('Answer:'):].strip()
        reading_question = False
    elif reading_question and line.strip() != '':
        # Append to the current question if reading in multi-line question
        current_question += ' ' + line.strip()
    elif not reading_question and line.strip() != '':
        # Append to the current answer if reading in multi-line answer
        current_answer += ' ' + line.strip()

# Append the last question-answer pair found
if current_question is not None and current_answer is not None:
    qa_pairs.append({
        "question": current_question.strip(),
        "answer": current_answer.strip()
    })

# Save extracted QA pairs to a JSON file
output_file = 'qa_pairs.json'

with open(output_file, 'w', encoding='utf-8') as json_file:
    json.dump(qa_pairs, json_file, ensure_ascii=False, indent=4)

print(f"Extracted {len(qa_pairs)} QA pairs saved to {output_file}")
