"""Corrective RAG LlamaPack class."""

import time
from typing import Any, Dict, List

from openai import OpenAI
from llama_index.core import VectorStoreIndex, SummaryIndex
from llama_index.core.llama_pack.base import BaseLlamaPack
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.schema import Document, NodeWithScore
from llama_index.core.query_pipeline.query import QueryPipeline
from llama_index.tools.tavily_research.base import TavilyToolSpec
from llama_index.core.prompts import PromptTemplate

DEFAULT_RELEVANCY_PROMPT_TEMPLATE = PromptTemplate(
    template="""As a grader, your task is to evaluate the relevance of a document retrieved in response to a user's question.

    Retrieved Document:
    -------------------
    {context_str}

    User Question:
    --------------
    {query_str}

    Evaluation Criteria:
    - Consider whether the document contains keywords or topics related to the user's question.
    - The evaluation should not be overly stringent; the primary objective is to identify and filter out clearly irrelevant retrievals.

    Decision:
    - Assign a binary score to indicate the document's relevance.
    - Use 'yes' if the document is relevant to the question, or 'no' if it is not.
    - DO NOT write anything else besides 'yes' or 'no'

    Please provide your binary score ('yes' or 'no') below to indicate the document's relevance to the user question."""
)

DEFAULT_TRANSFORM_QUERY_TEMPLATE = PromptTemplate(
    template="""Your task is to refine a query to ensure it is highly effective for retrieving relevant search results. \n
    Analyze the given input to grasp the core semantic intent or meaning. \n
    Original Query:
    \n ------- \n
    {query_str}
    \n ------- \n
    Your goal is to rephrase or enhance this query to improve its search performance. Ensure the revised query is concise and directly aligned with the intended search objective. \n
    Make sure the optimized query is a question and not a statement
    Respond with the optimized query only:"""
)

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information and without the use of prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Do not justify your answers.
    5. Do not restate questions or suggestions in your answer.
    6. Do not include extraneous symbols, tags, or prefixes.
    7. Do not add seemingly useless information once you have successfully answered the user's question.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

# # write prompt template with functions
# QA_PROMPT_EDITED = PromptTemplate(
#     template="""
#     Please mention how relevant information was not present in the documenation 
#     and that external sources were used to ensure an accurate response.\n\n
#     Context information is below.\n
#     ---------------------\n
#     {context_str}\n
#     ---------------------\n
#     Given the context information and not prior knowledge, 
#     answer the query.\n
#     Query: {query_str}\n
#     Answer: """
# )


class CorrectiveRAGPack(BaseLlamaPack):
    def __init__(self, tavily_ai_apikey: str) -> None:
        """Init params."""
        self.client = OpenAI()
        llm = OpenAI_Llama(model="gpt-4o")
        self.relevancy_pipeline = QueryPipeline(
            chain=[DEFAULT_RELEVANCY_PROMPT_TEMPLATE, llm]
        )
        self.transform_query_pipeline = QueryPipeline(
            chain=[DEFAULT_TRANSFORM_QUERY_TEMPLATE, llm]
        )

        self.llm = llm
        self.tavily_tool = TavilyToolSpec(api_key=tavily_ai_apikey)


    def evaluate_relevancy(
        self, retrieved_nodes: List[Document], query_str: str
    ) -> List[str]:
        """Evaluate relevancy of retrieved documents with the query."""
        relevancy_results = []
        for node in retrieved_nodes:
            relevancy = self.relevancy_pipeline.run(
                context_str=node.text, query_str=query_str
            )
            relevancy_results.append(relevancy.message.content.lower().strip())
        return relevancy_results

    def extract_relevant_texts(
        self, retrieved_nodes: List[NodeWithScore], relevancy_results: List[str]
    ) -> List[str]:
        """Extract relevant texts from retrieved documents."""
        relevant_texts = [
            retrieved_nodes[i].text
            for i, result in enumerate(relevancy_results)
            if result == "yes"
        ]
        return relevant_texts

    def search_with_transformed_query(self, query_str: str) -> str:
        """Search the transformed query with Tavily API."""
        query_str = "In Radiant Logic Documentation, " + query_str
        search_results = self.tavily_tool.search(query_str, max_results=15)
        useful_info = [result.text for result in search_results if result.extra_info['url'].startswith("https://developer.radiantlogic.com/")][:5]
        return useful_info

    def get_result(self, context: List[str], query_str: str) -> Any:
        """Get result with relevant text."""
        context_str = "\n\n".join(context)

        prompt = QA_USER_PROMPT.format(context_str=context_str, query_str=query_str)
        answer = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": QA_SYSTEM_PROMPT},
                {"role": "user", "content": prompt}
            ]
        ).choices[0].message.content

        # nodes returned for debugging purposes
        return context, answer

    def run(self, retrieved_nodes, query_str: str, **kwargs: Any) -> Any:
        """Run the pipeline."""

        # Evaluate the relevancy of each retrieved document in relation to the query string.
        relevancy_results = self.evaluate_relevancy(retrieved_nodes, query_str)
        # Extract texts from documents that are deemed relevant based on the evaluation.
        relevant_text = self.extract_relevant_texts(retrieved_nodes, relevancy_results)

        # Initialize search_text variable to handle cases where it might not get defined.
        search_text = []

        # If any document is found irrelevant, transform the query string for better search results.
        if not relevant_text:
            transformed_query_str = self.transform_query_pipeline.run(
                query_str=query_str
            ).message.content
            # Conduct a search with the transformed query string and collect the results.
            search_text = self.search_with_transformed_query(transformed_query_str)
            if search_text:
                return self.get_result(search_text, query_str)
            else:
                # MAKE BETTER LATER
                return [], "This doesn't appear to be in my documentation."
        else:
            return self.get_result(relevant_text, query_str)
