import os
import json
import lancedb
import time
import nest_asyncio
import numpy as np
from openai import OpenAI
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.core import StorageContext
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
nest_asyncio.apply()

client = OpenAI()

reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)

db = lancedb.connect("./lancedb_new")

table = db.open_table("docs_OpenAI")
# table = db.open_table("docs_OpenAI_hierarchical")
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)
storage_context = StorageContext.from_defaults(persist_dir="./storage_new_OpenAI")

retriever = index.as_retriever(similarity_top_k=40)
# retriever = index.as_retriever(similarity_top_k=40)

# base_retriever = index.as_retriever(similarity_top_k=40)
auto_retriever = AutoMergingRetriever(retriever, storage_context=storage_context, simple_ratio_thresh=0)


with open("qa_pairs.json", 'r') as file:
    data = json.load(file)
    time1 = 0
    time2 = 0
    time3 = 0
    time4 = 0
    for i, entry in enumerate(data, start=1):
        print("Question: " + str(i))
        query = entry['question']

        st1 = time.time()
        auto_nodes = retriever.retrieve(query)
        a = auto_retriever._get_parents_and_merge(auto_nodes)
        et1 = time.time() - st1

        time1 += et1
        time2 += et1
        time3 += et1
        time4 += et1

        st2 = time.time()
        reranked_nodes2 = reranker.postprocess_nodes(auto_nodes, query_str=query)
        b = auto_retriever._get_parents_and_merge(reranked_nodes2)
        et2 = time.time() - st2

        time2 += et2
        time4 += et2

        st3 = time.time()
        final_nodes2 = reranker2.postprocess_nodes(reranked_nodes2, query_str=query)
        c = auto_retriever._get_parents_and_merge(final_nodes2)
        et3 = time.time() - st3
        
        time3 += et3

        st4 = time.time()
        second_half = reranked_nodes2[5:]
        first_half = reranked_nodes2[:5]
        final_nodes3 = reranker2.postprocess_nodes(first_half, query_str=query)
        combined_nodes = final_nodes3 + second_half
        d = auto_retriever._get_parents_and_merge(combined_nodes)
        et4 = time.time() - st4

        time4 += et4

print(time1 / 37)
print(time2 / 37)
print(time3 / 37)
print(time4 / 37)