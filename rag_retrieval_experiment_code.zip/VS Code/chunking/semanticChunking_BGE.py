import os
import lancedb
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core import StorageContext
from llama_index.core import Settings
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from lancedb.embeddings import get_registry
from lancedb.rerankers import LinearCombinationReranker
from llama_index.core.node_parser import SemanticSplitterNodeParser
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'


db = lancedb.connect("./lancedb")

documents = SimpleDirectoryReader(input_files=["document_info/Lexus.docx"]).load_data()

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-large-en-v1.5"
)

splitter = SemanticSplitterNodeParser(
    buffer_size=1, breakpoint_percentile_threshold=95, embed_model=Settings.embed_model
)

nodes = splitter.get_nodes_from_documents(documents)

reranker = LinearCombinationReranker()

vector_store = LanceDBVectorStore(uri="./lancedb", table_name="semantic_BGE", query_type="vector", reranker=reranker)

storage_context = StorageContext.from_defaults(vector_store=vector_store)

index = VectorStoreIndex(nodes=nodes, storage_context=storage_context)

retriever = index.as_retriever(similarity_top_k=10)
nodes = retriever.retrieve("apple")
print("done")