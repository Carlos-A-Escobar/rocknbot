import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings, Document
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.node_parser import MarkdownNodeParser
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
import nest_asyncio

def extract_metadata_from_lines(lines):
    metadata = {}
    for line in lines:
        if line.startswith('title:'):
            metadata['title'] = line.split(':', 1)[1].strip()
        elif line.startswith('description:'):
            metadata['description'] = line.split(':', 1)[1].strip()
        elif line.startswith('keywords:'):
            metadata['keywords'] = line.split(':', 1)[1].strip()
    return metadata

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

node_parser = MarkdownNodeParser()
reader = MarkdownReader()
file_extractor = {".md": reader}
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
pipeline = IngestionPipeline(transformations=[node_parser])

all_nodes = []
documents = SimpleDirectoryReader(
    input_files=['docs/IDA/documentation-ia-product-descartes/documentation/igrc-platform/getting-started/05-studio-editors.md'], file_extractor=file_extractor
).load_data()

with open('docs/IDA/documentation-ia-product-descartes/documentation/igrc-platform/getting-started/05-studio-editors.md', 'r', encoding='utf-8') as f:
    first_lines = []
    for _ in range(5):
        try:
            first_lines.append(next(f).strip())
        except StopIteration:
            break

metadata = extract_metadata_from_lines(first_lines)
metadata["version"] = "7.4"
metadata["product_tag"] = "IDDM"

for doc in documents:
    for label in metadata:
        doc.metadata[label] = metadata[label]

nodes = pipeline.run(documents=documents, in_place=False, show_progress=True)
all_nodes.extend(nodes)

Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")

vector_store = LanceDBVectorStore(uri='lancedb', table_name='IDDM', query_type='hybrid')
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex(nodes=all_nodes, storage_context=storage_context)