import os
import pickle
import openai
import lancedb
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from openai import OpenAI
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from lancedb.embeddings import get_registry
from lancedb.rerankers import LinearCombinationReranker
from llama_index.core.node_parser import (
    SentenceSplitter,
    SemanticSplitterNodeParser,
)
# from pymongo import MongoClient
import nest_asyncio

nest_asyncio.apply()
# Set up OpenAI and create embedding function
os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

# openai_client = OpenAI(api_key=OPENAI_API_KEY)
# client = MongoClient(MONGO_URI)
# db_mongo = client['docs']
# collection = db_mongo.index

db = lancedb.connect("./lancedb")

# documents = SimpleDirectoryReader(input_dir="radiantlogic_docs/docx/").load_data()
documents = SimpleDirectoryReader(input_files=["document_info/Lexus.docx"]).load_data()

Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')

splitter = SemanticSplitterNodeParser(
    buffer_size=1, breakpoint_percentile_threshold=95, embed_model=Settings.embed_model
)

nodes = splitter.get_nodes_from_documents(documents)

reranker = LinearCombinationReranker()

vector_store = LanceDBVectorStore(uri="./lancedb", table_name="semantic_OpenAI", query_type="vector", reranker=reranker)

storage_context = StorageContext.from_defaults(vector_store=vector_store)

index = VectorStoreIndex(nodes=nodes, storage_context=storage_context)

retriever = index.as_retriever(similarity_top_k=10)
nodes = retriever.retrieve("apple")
print("done")