import os
import lancedb
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import SentenceSplitter
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import StorageContext
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.vector_stores.lancedb import LanceDBVectorStore
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

documents = SimpleDirectoryReader(input_dir="./document_info/").load_data()
splitter = SentenceSplitter(
    chunk_size=256,
    chunk_overlap=20,
)

nodes = splitter.get_nodes_from_documents(documents)

# OPENAI
Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')
vector_store = LanceDBVectorStore(uri="./lancedb", table_name="sentence_OpenAI", query_type="vector")
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex(nodes=nodes, storage_context=storage_context)

# # MINILM
# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="sentence-transformers/all-MiniLM-L12-v2"
# )
# vector_store2 = LanceDBVectorStore(uri="./lancedb", table_name="sentence_MiniLM", query_type="vector")
# storage_context2 = StorageContext.from_defaults(vector_store=vector_store2)
# index2 = VectorStoreIndex(nodes=nodes, storage_context=storage_context2)

# # BGE
# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="BAAI/bge-large-en-v1.5"
# )
# vector_store3 = LanceDBVectorStore(uri="./lancedb", table_name="sentence_BGE", query_type="vector")
# storage_context3 = StorageContext.from_defaults(vector_store=vector_store3)
# index3 = VectorStoreIndex(nodes=nodes, storage_context=storage_context3)