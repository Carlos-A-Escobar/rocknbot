import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

db = lancedb.connect("./lancedb")

documents = SimpleDirectoryReader(input_dir="./good_docs/").load_data()
node_parser = HierarchicalNodeParser.from_defaults()
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
pipeline = IngestionPipeline(transformations=[node_parser])
nodes = pipeline.run(documents=documents, in_place=False, show_progress=True)
leaf_nodes = get_leaf_nodes(nodes)

# OPENAI
Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')
vector_store = LanceDBVectorStore(uri="./lancedb_new", table_name="hierarchical_OpenAI_RL", query_type="vector")
docstore = SimpleDocumentStore()
docstore.add_documents(nodes)
storage_context = StorageContext.from_defaults(vector_store=vector_store, docstore=docstore)
index = VectorStoreIndex(nodes=leaf_nodes, storage_context=storage_context)
index.storage_context.persist(persist_dir="./storage_new/hierarchical_OpenAI_RL")

# # MINILM
# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="sentence-transformers/all-MiniLM-L12-v2"
# )
# vector_store2 = LanceDBVectorStore(uri="./lancedb", table_name="hierarchical_MiniLM", query_type="vector")
# docstore2 = SimpleDocumentStore()
# docstore2.add_documents(nodes)
# storage_context2 = StorageContext.from_defaults(vector_store=vector_store2, docstore=docstore2)
# index2 = VectorStoreIndex(nodes=leaf_nodes, storage_context=storage_context2)
# index2.storage_context.persist(persist_dir="./storage_MiniLM")

# BGE
Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-large-en-v1.5"
)
vector_store3 = LanceDBVectorStore(uri="./lancedb_new", table_name="hierarchical_RL", query_type="vector")
docstore3 = SimpleDocumentStore()
docstore3.add_documents(nodes)
storage_context3 = StorageContext.from_defaults(vector_store=vector_store3, docstore=docstore3)
index3 = VectorStoreIndex(nodes=leaf_nodes, storage_context=storage_context3)
index3.storage_context.persist(persist_dir="./storage_new/hierarchical_BGE_RL")