import os
import time
import shutil
import lancedb
import copy
import git
import openai
import tiktoken
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings, Document
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.node_parser import MarkdownNodeParser, SentenceSplitter
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

db = lancedb.connect("./lancedb")
failed_clone_messages = ""

PRODUCT_REPOS_DICT = {
    "IDDM": [
        ("https://github.com/radiantlogic-v8/documentation-new.git", ["v7.4", "v8.0", "v8.1", "r1-saas"]),
        ("https://github.com/radiantlogic-v8/documentation-eoc.git", ["latest"])
    ],
    "IDA": [
        ("https://github.com/radiantlogic-v8/documentation-identity-analytics.git", ["iap-2.0", "iap-2.2", "iap-3.0"]),
        ("https://github.com/radiantlogic-v8/documentation-ia-product.git", ["descartes", "descartes-dev"]),
        ("https://github.com/radiantlogic-v8/documentation-ia-selfmanaged.git", ["version-1.5", "version-16"])
    ]
}

# Function to get all .md files in a directory recursively
def find_md_files(directory):
    md_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".md"):
                md_files.append(os.path.join(root, file))
    return md_files

def extract_metadata_from_lines(lines):
    metadata = {}
    for line in lines:
        if line.startswith('title:'):
            metadata['title'] = line.split(':', 1)[1].strip()
        elif line.startswith('description:'):
            metadata['description'] = line.split(':', 1)[1].strip()
        elif line.startswith('keywords:'):
            metadata['keywords'] = line.split(':', 1)[1].strip()
        
    return metadata


def clone_repo(repo_url, target_dir, branch):
    try:
        print(f"cloning {repo_url}, {branch}")
        git.Repo.clone_from(repo_url, target_dir, branch=branch)
        return True
    except Exception as e:
        # print(f"Failed to clone {repo_url}: {e}")
        return False

# Initialize model and pipeline
splitter = SentenceSplitter(
    chunk_size=1024,
    chunk_overlap=20,
)
node_parser = MarkdownNodeParser()
reader = MarkdownReader()
file_extractor = {".md": reader}
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
pipeline = IngestionPipeline(transformations=[node_parser])

base_dir = "./docs2/"
os.makedirs(base_dir, exist_ok=True)
all_nodes = []

for product, repo_branches in PRODUCT_REPOS_DICT.items():
    product_dir = os.path.join(base_dir, product)
    os.makedirs(product_dir, exist_ok=True)

    max_retries = 10
    
    for repo_url, branches in repo_branches:
        for branch in branches:
            repo_name = repo_url.split('/')[-1].replace('.git', '')
            target_dir = os.path.join(product_dir, repo_name) + "/" + branch
            if os.path.exists(target_dir):
                # shutil.rmtree(target_dir)
                print('done')
            else:
                attempt = 0
                success = False
                while attempt < max_retries and not success:
                    success = clone_repo(repo_url, target_dir, branch)
                    if not success:
                        attempt += 1
                        if attempt < max_retries:
                            # print(f"Retrying in 10 seconds... (Attempt {attempt + 1}/{max_retries})")
                            time.sleep(10)
                        else:
                            failed_clone_messages += "Max retries reached. Failed to clone {repo_url} into {target_dir}. "
                    
            md_files = find_md_files(target_dir)
            print(len(md_files))

            for file in md_files:
                with open(file, 'r', encoding='utf-8') as f:
                    first_lines = []
                    for _ in range(5):
                        try:
                            first_lines.append(next(f).strip())
                        except StopIteration:
                            break

                metadata = extract_metadata_from_lines(first_lines)
                metadata["version"] = branch

                documents = SimpleDirectoryReader(
                    input_files=[file], file_extractor=file_extractor
                ).load_data()

                for doc in documents:
                    for label in metadata:
                        doc.metadata[label] = metadata[label]
                nodes = pipeline.run(documents=documents, in_place=False)
                for node in nodes:
                    node.excluded_llm_metadata_keys = ['file_path', 'file_name', 'file_type', 'file_size', 'creation_date', 'last_modified_date']
                    node.excluded_embed_metadata_keys = ['file_path', 'file_name', 'file_type', 'file_size', 'creation_date', 'last_modified_date']

                all_nodes.extend(nodes)

    enc = tiktoken.encoding_for_model("gpt-3.5-turbo")
    for node in all_nodes:
        node.excluded_llm_metadata_keys = ['file_path', 'file_name', 'file_type', 'file_size', 'creation_date', 'last_modified_date']
        node.excluded_embed_metadata_keys = ['file_path', 'file_name', 'file_type', 'file_size', 'creation_date', 'last_modified_date']
        length = len(enc.encode(node.text))
        if length > 7000:
            document = Document(text=node.text, metadata=node.metadata)
            new_nodes = splitter.get_nodes_from_documents(documents=[document])
            all_nodes.remove(node)
            all_nodes.extend(new_nodes)

    print(len(all_nodes))
    Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")

    try:
        db.drop_table(product)
    except Exception as e:
        continue
    vector_store = LanceDBVectorStore(uri='lancedb', table_name=product, query_type='hybrid')
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes=all_nodes[:1], storage_context=storage_context)
    index.insert_nodes(all_nodes[1:])

# # table = db.open_table(product)
# # qa_pairs_in_db_count = len(table.search().limit(20000).to_list())
# # print(f"Nodes in DB count: {qa_pairs_in_db_count}")
# # if qa_pairs_inserted_count != qa_pairs_in_db_count:
#     print("Something went wrong. Contact an admin ASAP.")
# print(f"Inserted {qa_pairs_inserted_count} qa pairs into db. Number of qa pairs in db: {qa_pairs_in_db_count}")
# shutil.rmtree(base_dir)