import lancedb
import os
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

db = lancedb.connect("./lancedb_RL")

# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="BAAI/bge-large-en-v1.5"
# )
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
table = db.open_table('sentence_OpenAI')
vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)
retriever = index.as_retriever(similarity_top_k = 5000)
nodes1 = retriever.retrieve("qwertyuioplkjhgfdsazxcvbnm")
set1 = set()
for node in nodes1:
    set1.add(node.id_)

