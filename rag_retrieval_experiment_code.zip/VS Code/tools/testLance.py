import os
import lancedb
import pickle
from llama_index.core import VectorStoreIndex, StorageContext
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.rerankers import LinearCombinationReranker
from pymongo import MongoClient
from openai import OpenAI
from ragatouille import RAGTrainer
from ragatouille import RAGPretrainedModel

import nest_asyncio
import time

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-large-en-v1.5"
)
os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

nest_asyncio.apply()

st1 = time.time()
db = lancedb.connect(uri="./lancedb_RL_test")
table = db.open_table("docs")
vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store=vector_store)
et1 = time.time() - st1


st3 = time.time()
file_storage = StorageContext.from_defaults(persist_dir="./RL_test")
et3 = time.time() - st3


question = "what is the environment operations center?"
lance_filter = f"metadata.version = '7/4' "
# base_retriever = index.as_retriever(vector_store_kwargs={"where": lance_filter}, similarity_top_k=10, prefilter=True)
base_retriever = index.as_retriever(similarity_top_k=10)

response = base_retriever.retrieve(question)
retriever = AutoMergingRetriever(base_retriever, file_storage, verbose=True)


st4 = time.time()
nodes = retriever.retrieve(question)
et4 = time.time() - st4

print('done')