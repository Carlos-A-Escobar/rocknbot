
from llama_index.core import SimpleDirectoryReader
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core import Settings
from ragatouille import RAGPretrainedModel

# chunks = ["cat", "dog", "sheep," "fox", "elephant", "tiger", "lion", "monkey", "giraffe", "rhino"]

documents = SimpleDirectoryReader(input_files=["document_info/Lexus.docx"]).load_data()
node_parser = HierarchicalNodeParser.from_defaults()
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")

extractors = [
    QuestionsAnsweredExtractor(questions=3, llm=Settings.llm),
    SummaryExtractor(),
]

pipeline = IngestionPipeline(transformations=[node_parser])
# extractor_pipeline = IngestionPipeline(transformations=[*extractors])

nodes = pipeline.run(documents=documents, in_place=False, show_progress=True)
chunks = [node.text for node in nodes]

RAG = RAGPretrainedModel.from_pretrained("colbert-ir/colbertv2.0")

index_path = RAG.index(
    collection=chunks,
    index_name="chunks",
    max_document_length=8192,
    split_documents=False
)

print('done')