import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from lancedb.embeddings import get_registry
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

db = lancedb.connect("./lancedb")

model = GLiNER.from_pretrained("EmergentMethods/gliner_medium_news-v2.1")
documents = SimpleDirectoryReader(input_dir="test_docs/").load_data()
node_parser = HierarchicalNodeParser.from_defaults(chunk_sizes=[128, 512, 2048])
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
pipeline = IngestionPipeline(transformations=[node_parser])
nodes = pipeline.run(documents=documents, in_place=False, show_progress=True)
leaf_nodes = get_leaf_nodes(nodes)
# labels = ["Software", "Command", "File", "Parameter", "URL", "Service", "Example"]
labels = ['Model Name', 'Year', 'Event', 'Feature']

label_to_key = {
    'Model Name': 'model_name',
    'Year': 'year',
    'Event': 'event',
    'Feature': 'feature'
}

# Iterate over the leaf nodes
for node in leaf_nodes:
    # Initialize all keys in the node's metadata with an empty string
    for label in labels:
        key = label_to_key[label]
        if key not in node.metadata:
            node.metadata[key] = ""
    
    # Predict entities for the current node's text
    entities = model.predict_entities(node.text, labels=labels)
    
    # Update the metadata with the predicted entities
    for entity in entities:
        label = entity['label']
        key = label_to_key[label]
        value = entity['text']
        if node.metadata[key]:
            node.metadata[key] = f"{node.metadata[key]},{value}"
        else:
            node.metadata[key] = value

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-large-en-v1.5"
)
vector_store = LanceDBVectorStore(uri="./lancedb", table_name="BGE_Lexus", query_type="vector")
docstore = SimpleDocumentStore()
docstore.add_documents(nodes)
storage_context = StorageContext.from_defaults(vector_store=vector_store, docstore=docstore)
index = VectorStoreIndex(nodes=leaf_nodes, storage_context=storage_context)
index.storage_context.persist(persist_dir="./BGE_Lexus_Metadata")