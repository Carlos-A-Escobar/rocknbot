import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from lancedb.embeddings import get_registry
import nest_asyncio
from llama_index.core.vector_stores import (
    MetadataFilters,
    FilterOperator,
    FilterCondition,
    MetadataFilter,
)

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

nest_asyncio.apply()

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-large-en-v1.5"
)

model = GLiNER.from_pretrained("EmergentMethods/gliner_medium_news-v2.1")
# db = lancedb.connect(uri="./lancedb")
# table = db.open_table("BGE_Lexus")
# ## REMINDER - CHANGE VECTORSTORE BACK TO HYBRID, CURRENTLY ON VECTOR
# vector_store = LanceDBVectorStore.from_table(table)
# index = VectorStoreIndex.from_vector_store(vector_store=vector_store)
# retriever = index.as_retriever(similarity_top_k=1000)
# nodes = retriever.retrieve("filler")

labels = ['Version']
label_to_key = {
    'Version': 'version',
}

query = "how do i remove a node from a cluster in v7.4?"
entities = model.predict_entities(query, labels=labels, threshold=0.9)
if entities:
    lance_filter_conditions = []

    # Update the metadata with the predicted entities
    for entity in entities:
        label = entity['label']
        key = label_to_key[label]
        value = entity['text']
        lance_filter_conditions.append(f"metadata.{key} LIKE %{value}%")

    lance_filter = " OR ".join(lance_filter_conditions)
    retriever = index.as_retriever(vector_store_kwargs={"where": lance_filter}, similarity_top_k=10, prefilter=True)
else :
    retriever = index.as_retriever(similarity_top_k=10)
response = retriever.retrieve("test")
print('hi')