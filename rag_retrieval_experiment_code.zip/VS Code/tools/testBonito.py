from bonito import Bonito
from vllm import SamplingParams
from datasets import Dataset

bonito = Bonito(model="BatsResearch/bonito-v1", dtype="float")

import docx

def read_docx(file_path):
    doc = docx.Document(file_path)
    content = []
    for para in doc.paragraphs:
        content.append(para.text)
    return content

file_path = './document_info/Lexus.docx'
docx_content = read_docx(file_path)

# Assuming each paragraph is a separate example in the dataset
data = {
    'text': docx_content
}

dataset = Dataset.from_dict(data)
print(dataset)