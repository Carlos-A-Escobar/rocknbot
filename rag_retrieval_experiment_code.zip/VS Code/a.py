import time
import os
import shutil
import git
import tiktoken
import lancedb

from llama_index.core import (
    Settings,
    SimpleDirectoryReader,
    Document,
    VectorStoreIndex,
    StorageContext
)
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.node_parser import MarkdownNodeParser, SentenceSplitter
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.readers.file import MarkdownReader
from llama_index_lancedb_vector_store import LanceDBVectorStore
from llama_index.embeddings.openai import OpenAIEmbedding

os.environ['OPENAI_API_KEY'] = '<YOUR_OPENAI_API_KEY_HERE>'
def clone_repo(repo_url, target_dir, branch):
    try:
        git.Repo.clone_from(repo_url, target_dir, branch=branch)
        return True
    except Exception:
        shutil.rmtree(target_dir)
        print(f"Failed to clone {repo_url}")
        return False
            
def find_md_files(directory):
    return [
        os.path.join(root, file)
        for root, _, files in os.walk(directory)
        for file in files
        if file.endswith(".md")
    ]

def extract_metadata_from_lines(lines):
    metadata = {}
    for line in lines:
        if line.startswith("title:"):
            metadata["title"] = line.split(":", 1)[1].strip()
        elif line.startswith("description:"):
            metadata["description"] = line.split(":", 1)[1].strip()
        elif line.startswith("keywords:"):
            metadata["keywords"] = line.split(":", 1)[1].strip()

    return metadata

db = lancedb.connect("./lancedb")

failed_clone_messages = ""

product_repos_dict = {
            "IDDM": [
                ("https://github.com/radiantlogic-v8/documentation-new.git", ["v7.4", "v8.0", "v8.1"]),
                ("https://github.com/radiantlogic-v8/documentation-eoc.git", ["latest"]),
            ],
            "IDA": [
                ("https://github.com/radiantlogic-v8/documentation-identity-analytics.git", ["iap-2.0", "iap-2.2", "iap-3.0"]),
                ("https://github.com/radiantlogic-v8/documentation-ia-product.git", ["descartes", "descartes-dev"]),
                ("https://github.com/radiantlogic-v8/documentation-ia-selfmanaged.git", ["version-1.5", "version-16"]),
            ],
        }

excluded_metadata_keys = [
            "file_path",
            "file_name",
            "file_type",
            "file_size",
            "creation_date",
            "last_modified_date",
            "github_url",
            "version"
        ]


splitter = SentenceSplitter(
        chunk_size=1024,
        chunk_overlap=20,
    )
node_parser = MarkdownNodeParser()
reader = MarkdownReader()
file_extractor = {".md": reader}
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
pipeline = IngestionPipeline(transformations=[node_parser])

os.makedirs("./docs", exist_ok=True)

all_nodes = []

for product, repo_branches in product_repos_dict.items():
    product_dir = os.path.join('./docs', product)
    os.makedirs(product_dir, exist_ok=True)

    max_retries = 5

    for repo_url, branches in repo_branches:
        for branch in branches:
            repo_name = repo_url.rsplit("/", 1)[-1].replace(".git", "")
            target_dir = os.path.join(product_dir, repo_name) + "/" + branch
            # if os.path.exists(target_dir):
            #     shutil.rmtree(target_dir)
            # # Sometimes cloning a github repo fails.
            # attempt = 0
            # success = False
            # while attempt < max_retries and not success:
            #     success = clone_repo(repo_url, target_dir, branch)
            #     if not success:
            #         attempt += 1
            #         if attempt < max_retries:
            #             time.sleep(10)
            #         else:
            #             print(f"Max retries reached. Failed to clone {repo_url}, binto {target_dir}.")
            md_files = find_md_files(target_dir)
            for file in md_files:
                with open(file, "r", encoding="utf-8") as f:
                    first_lines = []
                    for _ in range(5):
                        try:
                            first_lines.append(next(f).strip())
                        except StopIteration:
                            break

                metadata = extract_metadata_from_lines(first_lines)
                metadata["version"] = branch
                documents = SimpleDirectoryReader(
                                    input_files=[file], file_extractor=file_extractor
                                ).load_data()
                for document in documents:
                    for label, value in metadata.items():
                        document.metadata[label] = value
                    file_path = document.metadata['file_path']
                    relative_path = file_path.replace(f'docs/{product}/', '')
                    github_url = 'https://github.com/radiantlogic-v8/' + relative_path
                    github_url = github_url.replace(repo_name, repo_name + '/blob')
                    document.metadata['github_url'] = github_url
                    print(github_url)
                nodes = pipeline.run(documents=documents, in_place=False)
                     
                all_nodes.extend(nodes)

    enc = tiktoken.encoding_for_model("gpt-3.5-turbo")
    new_nodes_to_add = []
    nodes_to_remove = []

    for node in all_nodes:
        node.excluded_llm_metadata_keys = excluded_metadata_keys
        node.excluded_embed_metadata_keys = excluded_metadata_keys
        length = len(enc.encode(node.text))
        if length > 7000:
            nodes_to_remove.append(node)
            document = Document(text=node.text, metadata=node.metadata)
            new_nodes = splitter.get_nodes_from_documents(documents=[document])
            new_nodes_to_add.extend(new_nodes)
    all_nodes = [node for node in all_nodes if node not in nodes_to_remove]

    all_nodes.extend(new_nodes_to_add)

    Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")

    try:
        db.drop_table(product)
    except Exception:
        print('table was deleted already')
    vector_store = LanceDBVectorStore(uri="lancedb", table_name=product, query_type="hybrid")
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes=all_nodes[:1], storage_context=storage_context)
    index.insert_nodes(all_nodes[1:])
    print('vector store index created successfully')

print('hi')