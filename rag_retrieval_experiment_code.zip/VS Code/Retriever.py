import os
import json
import lancedb
import time
import random
import nest_asyncio
import numpy as np
from openai import OpenAI
from deepeval.synthesizer import Synthesizer
from deepeval import evaluate
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from llama_index.core.evaluation import DatasetGenerator
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings, StorageContext, SimpleDirectoryReader, Document
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from ragas.testset.generator import TestsetGenerator
from ragas.testset.evolutions import simple, reasoning, multi_context
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.embeddings.openai import OpenAIEmbedding
import pandas as pd
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import context_precision, context_recall, answer_correctness
from corrective_rag_pack.llama_index.packs.corrective_rag.base import CorrectiveRAGPack

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
nest_asyncio.apply()

client = OpenAI()

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information and without the use of prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.
    2. Avoid statements like 'Based on the context, ...' or 'The context information ...' or anything along those lines.
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Answer ALL parts of the user's query.ss
    5. Do not justify your answers.
    6. Do not restate questions or suggestions in your answer.
    7. Do not include extraneous symbols, tags, or prefixes.
    8. Do not add seemingly useless information once you have successfully answered the user's query.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ----------------------------------------------------\n
    {context_str}\n
    ----------------------------------------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

class my_retriever():
    def __init__(self):
        self.db = lancedb.connect("./lancedb_final")
        self.table = self.db.open_table("docs")
        Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
        self.vector_store = LanceDBVectorStore.from_table(self.table)
        self.index = VectorStoreIndex.from_vector_store(self.vector_store)
        self.reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-2-v2")
        self.retriever = self.index.as_retriever(similarity_top_k=30)

    def query(self, question):
        print("QUERYING")
        child_nodes = self.retriever.retrieve(question)
        cross_nodes = self.reranker.postprocess_nodes(child_nodes, query_str=question)[:5]
        return [node.text for node in cross_nodes]

        # chunks = ""
        # context = []
        # for node in cross_nodes:
        #     chunks += node.text
        #     chunks += "\n\n"
        #     context.append(node.text)

        # prompt = QA_USER_PROMPT.format(context_str=chunks, query_str=question)
        # response = client.chat.completions.create(
        #     model="gpt-4o",
        #     messages=[
        #         {"role": "system", "content": QA_SYSTEM_PROMPT},
        #         {"role": "user", "content": prompt}
        #     ]
        # ).choices[0].message.content

        # return [response, context]