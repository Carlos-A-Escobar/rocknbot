import os
import json
import lancedb
import time
import random
import nest_asyncio
import numpy as np
from openai import OpenAI
from deepeval.synthesizer import Synthesizer
from deepeval import evaluate
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from llama_index.core.evaluation import DatasetGenerator
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings, StorageContext, SimpleDirectoryReader
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from ragas.testset.generator import TestsetGenerator
from ragas.testset.evolutions import simple, reasoning, multi_context
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.embeddings.openai import OpenAIEmbedding
import pandas as pd
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import context_precision, context_relevancy, answer_relevancy, context_recall, answer_correctness

os.environ["OPENAI_API_KEY"] = '<YOUR_OPENAI_API_KEY_HERE>'
OPENAI_API_KEY = '<YOUR_OPENAI_API_KEY_HERE>'
nest_asyncio.apply()

directories = [
    './docs/7.4',
    './docs/8.0',
    './docs/8.1',
    './docs/eoc-latest',
    './docs/ia-product-descartes',
    './docs/ia-product-descartes-dev',
    './docs/ia-selfmanaged-1.5',
    './docs/identity-analytics-iap-2.2'
]

client = OpenAI()

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information and without the use of prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Do not justify your answers.
    5. Do not restate questions or suggestions in your answer.
    6. Do not include extraneous symbols, tags, or prefixes.
    7. Do not add seemingly useless information once you have successfully answered the user's question.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

LLM_EVALUATION_PROMPT = """
Given a question and it's ground truth, evaluate the generated answer.\n
Query: {query_str}\n
Ground Truth Answer: {ground_truth_answer}\n
Generated Answer: {generated_answer}\n
---------------------\n
Evaluation: \n\n
- Assign a score of 1 if the generated answer is correct.\n
- Assign a score of 0 if the generated answer is wrong.\n
- Only output "1" or "0"
"""
reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)

db = lancedb.connect("./lancedb_new")

# table = db.open_table("docs_OpenAI_hierarchical")
table = db.open_table("docs_OpenAI")
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
storage_context = StorageContext.from_defaults(persist_dir="./storage_new_OpenAI")

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)

base_retriever = index.as_retriever(similarity_top_k=30)
# base_retriever = index.as_retriever(similarity_top_k=40)
# auto_retriever = AutoMergingRetriever(base_retriever, storage_context=storage_context, simple_ratio_thresh=0)

def test_individual_question():
    query = "LDAP filter causing FID to not return memberOf attribute when querying a user"

    child_nodes = base_retriever.retrieve(query)

    cross_nodes = reranker.postprocess_nodes(child_nodes, query_str=query)

    colbert_nodes = reranker2.postprocess_nodes(cross_nodes, query_str=query)


    first_half = cross_nodes[:5]
    second_half = cross_nodes[5:]
    final_nodes3 = reranker2.postprocess_nodes(first_half, query_str=query)
    both_nodes = final_nodes3 + second_half


    rank_dict1 = {node.id_: rank for rank, node in enumerate(child_nodes, start=1)}
    rank_dict2 = {node.id_: rank for rank, node in enumerate(cross_nodes, start=1)}
    rank_dict3 = {node.id_: rank for rank, node in enumerate(colbert_nodes, start=1)}
    rank_dict4 = {node.id_: rank for rank, node in enumerate(both_nodes, start=1)}

    print("QUESTION: " + query)
    for node in child_nodes:
        print()
        print("------------------------------------------------")
        print("HYBRID RANK: " + str(rank_dict1[node.id_]) + ",   CROSSENCODER RANK: " + str(rank_dict2[node.id_]) + ",   COLBERT RANK: " + str(rank_dict3[node.id_]) + ",   BOTH RANK: " + str(rank_dict4[node.id_]))
        print()
        print(node.text)
        print("------------------------------------------------")
        print()

def deepeval():
    metrics = []
    common_params = {
        "threshold": 0.7,
        "model": "gpt-4o",
        "include_reason": False
    }

    answer_relevancy = AnswerRelevancyMetric(
        **common_params
    )

    contextual_precision = ContextualPrecisionMetric(
        **common_params
    )

    contextual_recall = ContextualRecallMetric(
        **common_params
    )

    contextual_relevancy = ContextualRelevancyMetric(
        **common_params
    )

    # hallucination = HallucinationMetric(
    #     **common_params
    # )

    metrics.append(answer_relevancy)
    metrics.append(contextual_precision)
    metrics.append(contextual_recall)
    metrics.append(contextual_relevancy)
    # metrics.append(hallucination)

    scores = [0] * 4

    with open("my_qa_pairs.json", 'r') as file:
        data = json.load(file)
        for entry in data:

            question = entry['question']
            # auto_nodes = auto_retriever.retrieve(question)
            auto_nodes = base_retriever.retrieve(question)
            reranked_nodes2 = reranker.postprocess_nodes(auto_nodes, query_str=question)[:5]
            # final_nodes3 = reranker2.postprocess_nodes(reranked_nodes2, query_str=question)
            context = []
            for node in reranked_nodes2:
                context.append(node.text)

            test_case = LLMTestCase(
                input=question,
                actual_output=entry['output_crossencoder'],
                expected_output=entry['answer'],
                retrieval_context=context
            )
            print("-------------------------------------")
            print("Question: " + question)
            print()
            print()
            print("Answer: " + entry['answer'])
            print()
            print()
            print("Generated Answer: " + entry['output_crossencoder'])
            print()
            print()
            print("-------------------------------------")
            for i, metric in enumerate(metrics):
                metric.measure(test_case)
                entry[metric.__name__] = metric.score
                scores[i] += metric.score
                print(metric.score)

    for score in scores:
        score = (score / len(data))
    data.append({"scores_crossencoder": scores})
    with open("my_qa_pairs.json", 'w') as file:
        json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation

def generate_answers():
    with open("my_qa_pairs.json", 'r') as file:
        question_num = 1
        data = json.load(file)
        for entry in data:
            if "question" not in entry:
                break
            print("\n" + str(question_num))
            question_num += 1

            question = entry['question']
            print("\nQuestion: " + question)
            nodes = base_retriever.retrieve(question)
            cross_nodes = reranker.postprocess_nodes(nodes, query_str=question)[:5]

            final_nodes = reranker2.postprocess_nodes(cross_nodes, query_str=question)

            chunks = ""
            chunks2 = ""

            for node in cross_nodes:
                chunks += node.text
                chunks += "\n\n"

            for node in final_nodes:
                chunks2 += node.text
                chunks2 += "\n\n"
                
            prompt = QA_USER_PROMPT.format(context_str=chunks, query_str=question)
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": QA_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ]
            )
            answer = entry['answer']
            generated_answer = response.choices[0].message.content

            print("\nAnswer: " + answer)
            print("\nGenerated Answer CROSSENCODER: " + generated_answer)
            entry['output_cross_hierarchical'] = generated_answer

            prompt2 = QA_USER_PROMPT.format(context_str=chunks2, query_str=question)
            response2 = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": QA_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt2}
                ]
            )
            generated_answer2 = response2.choices[0].message.content

            print("\nGenerated Answer BOTH: " + generated_answer2)
            entry['output_both_hierarchical'] = generated_answer2

            
        with open('my_qa_pairs.json', 'w') as file:
            json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation

def generate_ragas():
    reader = MarkdownReader()
    file_extractor = {".md": reader}

    files = find_md_files(directories)
    documents = SimpleDirectoryReader(
        input_files=files, file_extractor=file_extractor
    ).load_data()

    good_documents = []

    for doc in documents:
        length = len(doc.text)
        if length > 1000 and length < 3000:
            good_documents.append(doc)

    final_docments = random.sample(good_documents, 80)

    generator_llm = OpenAI_Llama(model="gpt-4o")
    critic_llm = OpenAI_Llama(model="gpt-4o")
    embeddings = OpenAIEmbedding(model="text-embedding-3-large")

    generator = TestsetGenerator.from_llama_index(
        generator_llm=generator_llm,
        critic_llm=critic_llm,
        embeddings=embeddings,
    )

    testset = generator.generate_with_llamaindex_docs(
        final_docments,
        test_size=80,
        distributions={simple: 0.3, reasoning: 0.4, multi_context: 0.3}
    )

    df = testset.to_pandas()
    df.to_excel('testsets/radiantlogic.xlsx', index=False)

def test_ragas():
    # with open("my_qa_pairs.json", "r") as file:
    #     data = json.load(file)

    # questions = [item['question'] for item in data]
    # ground_truths = [item['answer'] for item in data]
    # # answers = [item['output_cross_hierarchical'] for item in data]
    # answers = [item['output_both_hierarchical'] for item in data]
    # context = []

    # for question in questions:
    #     context_str = []
    #     nodes = auto_retriever.retrieve(question)
    #     cross_nodes = reranker.postprocess_nodes(nodes, query_str=question)[:5]
    #     # for node in cross_nodes:
    #     #     context_str.append(node.text)
    #     final_nodes = reranker2.postprocess_nodes(cross_nodes, query_str=question)
    #     for node in final_nodes:
    #         context_str.append(node.text)
    #     context.append(context_str)

    # data = {
    #     'question': questions,
    #     'ground_truth': ground_truths,
    #     'answer': answers,
    #     'contexts': context
    # }

    # df = pd.DataFrame(data)
    # df_duplicated = pd.concat([df] * 10, ignore_index=True)

    # dataset = Dataset.from_pandas(df_duplicated)




    contexts = []
    df = pd.read_excel("good_results/eval.xlsx")
    # df = df.rename(columns={'output_new_cross': 'answer'})
    # df = df.rename(columns={'output_new_both': 'answer'})

    print(list(df.columns))

    for i, question in enumerate(df['question'], start=1):
        print(str(i) + "/" + str(len(df['question'])))
        nodes = base_retriever.retrieve(question)
        reranked_nodes = reranker.postprocess_nodes(nodes, query_str=question)[:5]
        # nodes2 = auto_retriever._get_parents_and_merge(reranked_nodes)[0]
        # contexts.append([node.text for node in reranked_nodes])

        final_nodes = reranker2.postprocess_nodes(reranked_nodes, query_str=question)
        nodes2 = auto_retriever._get_parents_and_merge(final_nodes)[0]
        # contexts.append([node.text for node in final_nodes])
        contexts.append([node.text for node in nodes2])

    df['contexts'] = contexts

    print(list(df.columns))

    dataset = Dataset.from_pandas(df)

    result = evaluate(
        dataset,
        metrics=[
        context_precision,
        context_recall
        ]
    )
    df_result = result.to_pandas()

    df_result = df_result.drop('contexts', axis=1)
    # df_result = df_result.rename(columns={'answer': 'output_new_cross'})
    # df_result = df_result.rename(columns={'answer': 'output_new_both'})

    # Method 2: Save to a file
    df_result.to_excel('good_results/eval.xlsx', index=False)

def test_answer_correctness():
    scores = []
    df = pd.read_excel("good_results/eval.xlsx")

    for index, row in df.iterrows():
        question = row['question']
        ground_truth = row['ground_truth']
        answers = row["answer"]
        # output_cross = row['output_new_cross']
        # output_both = row['output_new_both']

        prompt = LLM_EVALUATION_PROMPT.format(query_str=question, ground_truth_answer=ground_truth, generated_answer=answers)

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "user", "content": prompt}
            ]
        )

        answer = response.choices[0].message.content

        if answer.strip().lower() == "1":
            scores.append(1)
        elif answer.strip().lower() == "0":
            scores.append(0)
        else:
            print("SCORE: " + answer.strip().lower())
            scores.append(-1)  # or any other default value as needed

    df['answer_correctness'] = scores

    df.to_excel('good_results/eval.xlsx', index=False)

def generate_answers_df():
    df = pd.read_excel("good_results/eval.xlsx")
    
    generated_answers = []
    for i, question in enumerate(df['question'], start=1):
        print(str(i) + "/" + str(len(df['question'])))
        st1 = time.time()
        question = "does Radiant Logic use the Apache Xalan Java XSLT library and Apache Batik?"
        nodes = base_retriever.retrieve(question)
        cross_nodes = reranker.postprocess_nodes(nodes, query_str=question)

        fh = cross_nodes[:5]
        sh = cross_nodes[5:]
        
        final_nodes = reranker2.postprocess_nodes(fh, query_str=question)

        final_3 = final_nodes + sh

        final_nodes2 = auto_retriever._get_parents_and_merge(final_3)[0][:5]

        et1 = time.time() - st1
        print(et1)
        # chunks = ""
        chunks2 = ""

        # for node in cross_nodes:
            # chunks += node.text
            # chunks += "\n\n"

        for node in final_nodes2:
            chunks2 += node.text
            chunks2 += "\n\n"
            
        prompt = QA_USER_PROMPT.format(context_str=chunks2, query_str=question)
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": QA_SYSTEM_PROMPT},
                {"role": "user", "content": prompt}
            ]
        )
        generated_answers.append(response.choices[0].message.content)
    df['answer'] = generated_answers

    df.to_excel("good_results/eval.xlsx", index=False)

def find_md_files(directories):
    md_files = []
    for directory in directories:
        for root, dir, files in os.walk(directory):
            for file in files:
                if file.endswith(".md"):
                    md_files.append(os.path.join(root, file))
    return md_files

test_individual_question()
# print('done')