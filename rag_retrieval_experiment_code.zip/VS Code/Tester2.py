from clean_document_retriever import DocumentRetriever
import os
import glob
import json
from deepeval.synthesizer import Synthesizer
from dotenv import dotenv_values
from typing import List, Optional
from llama_index.core.storage.docstore.types import BaseDocumentStore
from llama_index.core.schema import TextNode
from llama_index.storage.docstore.mongodb import MongoDocumentStore
from deepeval import evaluate
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from llama_index.core.node_parser import get_root_nodes


rag_env = dotenv_values("rag.env")
OPENAI_API_KEY = rag_env["OPENAI_API_KEY"]
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

class Tester2:
    def __init__(self):
        self.model = "gpt-3.5-turbo"
        self.data_output_path = "./data"
        self.num_questions_to_generate_per_doc = 10
        self.num_questions_to_generate_per_chunk = 5


    def generate_synthetic(
        self,
        input_dir: Optional[str] = None,
        input_files: Optional[List[str]] = None,
        docstore: Optional[BaseDocumentStore] = None,
        nodes: Optional[List[TextNode]] = None 
    ):
        files_to_process = []
        context = []
        if not any([input_dir, input_files, docstore, nodes]):
            raise ValueError("At least one of input_dir, input_files, docstore, or nodes must be provided.")
        
        if input_dir:
            if not os.path.isdir(input_dir):
                raise ValueError(f"The provided input_dir {input_dir} is not a valid directory.")
            files_to_process = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if os.path.isfile(os.path.join(input_dir, f))]
        elif input_files:
            if not all(os.path.isfile(f) for f in input_files):
                raise ValueError("One or more files in input_files are not valid files.")
            files_to_process = input_files

        # Check if docstore is of the correct type
        elif docstore:
            if not isinstance(docstore, BaseDocumentStore):
                raise ValueError("The provided docstore is not an instance of BaseDocumentStore.")
            context = [[node.text for node in docstore.docs.values()]]
        elif nodes:
            if any(not isinstance(node, TextNode) for node in nodes):
                raise ValueError("The provided nodes are not an instance of TextNode.")
            context = [[node.text for node in nodes]]

        synthesizer = Synthesizer()
        if files_to_process:
            synthesizer.generate_goldens_from_docs(
                document_paths=files_to_process,
                max_goldens_per_document=self.num_questions_to_generate_per_doc,
                include_expected_output=True
            )
        elif context:
            synthesizer.generate_goldens(
                contexts=context,
                max_goldens_per_context=self.num_questions_to_generate_per_chunk,
                include_expected_output=True
            )
        else:
            raise ValueError("Input is empty.")
        synthesizer.save_as(
            file_type='json',
            directory=self.data_output_path
        )


    def get_response(self):
        list_of_files = glob.glob('./data/*')
        latest_file = max(list_of_files, key=os.path.getctime)
        with open(latest_file, 'r') as file:
            synthetic_data = json.load(file)

        retriever = DocumentRetriever(model_name="gpt-3.5-turbo", storage_path="./storage")
        for entry in synthetic_data:
            if entry['actual_output'] is None:
                documents, response = retriever._evaluate_questions([entry['input']])
                entry['actual_output'] = response
                entry['retrieval_context'] = documents

        with open(latest_file, 'w') as result_file:
            json.dump(synthetic_data, result_file, indent=4)

        file.close()
        result_file.close()
        
    def runMetrics(self):
        
        metrics = []
        common_params = {
            "threshold": 0.7,
            "model": "gpt-4o",
            "include_reason": False
        }

        answer_relevancy = AnswerRelevancyMetric(
            **common_params
        )

        contextual_precision = ContextualPrecisionMetric(
            **common_params
        )

        contextual_recall = ContextualRecallMetric(
            **common_params
        )

        contextual_relevancy = ContextualRelevancyMetric(
            **common_params
        )

        # hallucination = HallucinationMetric(
        #     **common_params
        # )

        metrics.append(answer_relevancy)
        metrics.append(contextual_precision)
        metrics.append(contextual_recall)
        metrics.append(contextual_relevancy)
        # metrics.append(hallucination)

        list_of_files = glob.glob('./data/*')
        latest_file = max(list_of_files, key=os.path.getctime)

        with open(latest_file, 'r') as file:
            data = json.load(file)
            for entry in data:
                test_case = LLMTestCase(
                    input=entry['input'],
                    actual_output=entry['actual_output'],
                    expected_output=entry['expected_output'],
                    retrieval_context=entry['retrieval_context']
                )
                for metric in metrics:
                    metric.measure(test_case)
                    entry[metric.__name__] = metric.score

        with open(latest_file, 'w') as file:
            json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation


tester = Tester2()
tester.runMetrics()
