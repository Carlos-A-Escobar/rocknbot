import boto3
import json
from botocore.exceptions import ClientError

# Set your AWS credentials
aws_access_key_id = "AKIA2QETGWXF2YG2MP2G"
aws_secret_access_key = "A9RHHH2Ws+0WhC2BNFERbihkvGzwzLuBJTQCsOhq"

# Create a Bedrock Runtime client in the AWS Region you want to use.
client = boto3.client(
    "bedrock-runtime",
    region_name="us-east-1",
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
)

# Set the model ID, e.g., Llama 3 8b Instruct.
model_id = "meta.llama3-8b-instruct-v1:0"

# Start a conversation with the user message.
user_message = "Describe the purpose of a 'hello world' program in one line."
body = json.dumps({
    "prompt": user_message,
    "max_gen_len": 512,
    "top_p": 0.9,
    "temperature": 0.7
})

try:
    # Send the message to the model, using a basic inference configuration.
    response = client.invoke_model(
        body=body,
        modelId=model_id
    )

    # Extract and print the response text.
    res = response.get("body").read().decode('utf-8')
    resposne_body = json.loads(res)
    print(resposne_body['generation'].strip())

except (ClientError, Exception) as e:
    print(f"ERROR: Can't invoke '{model_id}'. Reason: {e}")
    exit(1)