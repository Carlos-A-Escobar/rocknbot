# Question/Answer Pair 0

Question: what are the cipher suites supported by RadiantOne v7.4?
Answer: To determine the cipher suites supported by the RadiantOne, follow these steps:

1. Open the RadiantOne Main Control Panel.
2. Go to the Settings tab and click on Security.
3. Under the SSL section, click on the Change button next to Supported Cipher Suites.
4. A list of cipher suites will be displayed, indicating the available options for encryption during the TLS handshake.
5. Restart the RadiantOne service for changes to take effect.

I hope this helps! Let me know if you have any further questions or need more assistance.


# Question/Answer Pair 0

Question: How do I create a virtual view of Entra ID (formerly named Azure AD)?
Answer: To create a virtual view of Entra ID in RadiantOne v7.4, you can follow these steps:

1. In Entra ID, create an application and make note of the APPLICATION ID and SECRET KEY generated. You will need these values in the next steps.

2. Go to the Main Control Panel &gt; Settings &gt; Server Backend &gt; Custom Data Sources. Select the mgraph data source and click Edit.

3. Select the username property and click Edit.

4. Enter the value of the Entra ID Application ID.

5. Select the password property and click Edit.

6. Enter the secret key associated with your Entra ID application.

7. Select the oauthURL property and click Edit.

8. Enter the URL for your Entra ID tenant token endpoint. This URL should look like: "<https://login.microsoftonline.com/&lt;your_tenant_name&gt;/oauth2/v2.0/token>".

9. Select the active property and click Edit.

10. Enter "true" to activate the data source.

11. Save the mgraph data source.

12. Go to the Main Control Panel &gt; Directory Namespace and create a new Root Naming Context using the "Virtual Tree" type.

13. Choose the "Use Existing View (.dvx)" option and browse to the mgraph.dvx file.

14. Test the virtual view by navigating below the root naming context where you mounted the mgraph.dvx file. You should see the entries from your Entra ID tenant.

That's it! You have successfully created a virtual view of Entra ID using RadiantOne. Let me know if you have any further questions.


# Question/Answer Pair 2

Question: How do I rebuild the index for a RadiantOne Directory store (formerly named HDAP)?
Answer: To rebuild the index for a RadiantOne Directory store, follow these steps:

1. Schedule a maintenance window for the re-indexing process, as it can take some time and the store will be inaccessible during this time.
2. Go to the Main Control Panel and navigate to the Directory Namespace tab.
3. Select the RadiantOne Directory store for which you want to rebuild the index.
4. On the Properties Tab, look for the "Re-build Index" button and click on it.
5. The re-indexing process will be executed on the leader node of the cluster.
6. Once the re-indexing is complete, the store on the leader node will be activated again.
7. All follower/follower-only nodes in the cluster will then copy the updated index from the leader node.

Remember, re-indexing should not be done frequently and should only be performed during scheduled maintenance windows.


# Question/Answer Pair 3

Question: What are computed attributes used for?
Answer: Computed attributes are used in RadiantOne to include attributes in virtual views that are derived from existing attributes. These computed attributes can be based on attributes from the primary object, secondary objects (from joins), and/or previously computed attributes. 


# Question/Answer Pair 4

Question: How do I deactivate a computed attribute for an LDAP proxy view in RadiantOne v7.4?
Answer: To deactivate a computed attribute in RadiantOne for an LDAP proxy view, please follow these steps:

1. Go to the Main Control Panel and select the Directory Namespace Tab.
2. Find the node that represents the LDAP backend below Root Naming Contexts and select it.
3. On the right side, click on the Objects Tab.
4. In the Primary Objects list, choose the object that contains the computed attribute(s) you want to deactivate.
5. Click on the Edit button next to Define Computed Attributes.
6. Uncheck the "Active" checkbox next to the computed attributes you want to deactivate.
7. Click OK to save the changes.
8. Finally, click Save to apply the changes.

By following these steps, you will be able to deactivate the computed attribute(s) as needed. Let me know if you have any further questions or need additional assistance!


# Question/Answer Pair 5

Question: How do I create a virtual view that joins across multiple heterogeneous data sources?
Answer: To create a virtual view that joins across multiple heterogeneous data sources in RadiantOne v7.4, you can follow these steps:

1. Open the Main Control Panel and navigate to the Context Builder tab.
2. Click on the View Designer tab.
3. Create a virtual view of the primary data source using the View Designer.
4. Next, create a virtual view of the secondary data source using the View Designer.
5. Open the virtual view of the primary data source in the View Designer.
6. In the view definition/tree, select the object where you want to define a join.
7. On the right side, select the Object tab.
8. In the "Join Profiles" section, click on the "NEW" button.
9. Select the "Regular" join type and click "NEXT".
10. Choose "Attribute Matching &gt; Join with Existing View" and click "NEXT".
11. Click on "Choose" and browse to select the virtual view of the secondary data source.
12. Select the attribute in the primary data source object and the secondary data source object that are in common and will indicate a link between matching entries across these sources.
13. Choose which attributes to return from the secondary object.
14. Click "Finish" and save the virtual view.

At runtime, RadiantOne will join the entries from the primary data source that have a matching entry in the secondary data source.


# Question/Answer Pair 6

Question: How do I delete a persistent cache?
Answer: To delete a persistent cache in RadiantLogic v7.4, follow these steps:

1. If the persistent cache is involved in inter-cluster replication, it is recommended to temporarily disable the replication before deleting the cache. This ensures data consistency across clusters. (This step is optional)

2. Open the RadiantOne Main Control Panel.

3. Go to the Directory Namespace tab.

4. Under the Cache section, select the branch of the cache you want to delete.

5. On the right side, uncheck the Active checkbox to deactivate the cache.

6. Click the Save button to apply the changes.

7. Finally, click the Delete button to delete the cache.

Please note that deleting a cache definition does not delete the underlying naming context the cache was created for.

Let me know if you need further assistance!


# Question/Answer Pair 7

Question: How do I delete a root naming context?
Answer: To delete a root naming context in RadiantOne v7.4, follow these steps:

1. Open the RadiantOne Main Control Panel.
2. Go to the Directory Namespace Tab.
3. Find the naming context you want to delete under the Root Naming Contexts node.
4. Uncheck the Active option on the right side.
5. Click the Save button.
6. A prompt will appear asking if you want to apply the changes to the server. Click Yes.
7. Another prompt will appear confirming the deactivation. Click OK.
8. Click the delete button (trash can icon).
9. Confirm the deletion by clicking Yes.
10. Click OK to exit the confirmation.

That's it! The root naming context has been successfully deleted.

Please note that if the naming context contains levels with multiple backends mounted under it, each of these must be deleted prior to deleting the root naming context.


# Question/Answer Pair 8

Question: How do I change the FID server log levels in RadiantOne?
Answer: To change the log level for RadiantOne FID, follow these steps:

1. Open the Main Control Panel.
2. Navigate to the "Settings" section and click on "Logs".
3. In the "Log Settings" page, select "VDS - Server" from the "Log Settings to Configure" drop-down list.
4. Locate the "Log Level" drop-down list and choose the desired log level.
5. Click on the "Save" button to apply the changes.

By following these steps, you will be able to modify the log level for RadiantOne FID. Let me know if you need further assistance!


# Question/Answer Pair 9

Question: What components make up the RadiantOne v7.4 Synchronization architecture?
Answer: The components that make up the Synchronization architecture are Agents, Queues, Sync Engine, Attribute mappings, and transformation scripts. Agents manage Connectors, which are used to interface with the data sources. Changes flow to and from the Connectors asynchronously in the form of messages, which are temporarily stored in queues. The Sync Engine processes the attribute mappings and transformation scripts before sending the events to the target endpoints.


# Question/Answer Pair 10

Question: What is a topology in RadiantOne v7.4 Synchronization?
Answer: A topology in Synchronization refers to the naming and graphical representation of a set of objects involved in a synchronization process. It shows how the synchronization flows are grouped and depicted as pipelines. A topology can have one or more pipelines, which are automatically generated when the topology is created. You cannot manually create your own pipelines.


# Question/Answer Pair 13

Question: Where do I find the Pipeline ID for my topology in RadiantOne v7.4 Synchronization?
Answer: To find the Pipeline ID for your topology in Synchronization, follow these steps:

1. Go to the Main Control Panel.
2. Click on the Synchronization tab.
3. Select the desired topology from the list on the left.
4. On the right side, hover over the name of the pipeline.
5. The Pipeline ID will be displayed.

You can also find the pipeline ID using the vdsconfig command line utility with the list-topologies command. The “pipelinesIdentifiers” property returns the pipeline ID.

That's it! You have now found the Pipeline ID for your topology in RadiantOne Synchronization. Let me know if you need any further assistance.


# Question/Answer Pair 14

Question: How do I edit attribute mappings in RadiantOne v7.4 Synchronization?
Answer: To edit attribute mappings in RadiantOne v7.4 Synchronization, follow these steps:

1. Go to the Main Control Panel.
2. Click on the Synchronization tab.
1. Select the desired topology from the list on the left.
2. Click on the pipeline you want to configure.
3. In the Transformation component, expand the Mappings section at the bottom.
4. Find the pipeline mapping that contains the attribute mapping you want to edit and click on the edit button (pencil icon).
5. Look for the attribute mapping you want to edit in the list and click on the edit button next to it.
6. Make the necessary edits to the attribute mapping.
7. Once you're done editing, click on the Save button to save your changes.

That's it! You have successfully edited the attribute mapping in RadiantOne v7.4 Synchronization.


# Question/Answer Pair 15

Question: What are the possible Actions that a Synchronization Rule can result in?
Answer: A Synchronization Rule can result in the following possible actions:

1. Abort: This action allows you to decide not to propagate the changes to the target system. It means that if the conditions of the rule are met, the changes will not be applied to the target system.

2. Apply Target Attribute Mappings: This action involves transforming input values in preparation for applying them to the target system. Attribute mappings define how the input values should be transformed. You can reuse existing attribute mappings or create new ones.

3. Custom Function: This action gives you the flexibility to create a custom function or call an existing function. It allows you to add your own code to handle situations where the default actions are not sufficient.

These are the possible actions that can be associated with a Synchronization Rule. Let me know if you need further assistance or have any other questions!


# Question/Answer Pair 16

Question: What are Rules in RadiantOne Synchronization?
Answer: A rule in RadiantOne Synchronization categorizes a set of conditions in a source system and the set of actions that must be taken in a target system if the conditions are met. Each rule has defined conditions and actions. You can define multiple rules for a transformation, and by default, all rules are evaluated in the order they are defined.


# Question/Answer Pair 17

Question: What is the role of a Connector in RadiantOne Synchronization?
Answer: A Connector in Synchronization has three main functions. First, it queries data sources and collects changed entries. Second, it filters out unneeded events. And third, it publishes the changed entries with the required information. Connectors are responsible for capturing changes on entries in data sources and are used by RadiantOne Synchronization to propagate changes from source systems to one or more target systems. The specific type of connector used depends on the type of data store being used, such as an LDAP directory or an RDBMS.


# Question/Answer Pair 19

Question: How long do unprocessed messages remain the queues in RadiantOne Synchronization?
Answer: The unprocessed messages in the queues of RadiantOne Synchronization remain there until they are picked up by the sync engine or until the message time-to-live has been reached. By default, the message time-to-live is set to 3 days. You can configure the message time-to-live in the "Changelog and Replicationjournal Max Age" property in the Main Control Panel, Settings, Log, Changelog section. To view the queues, you can search for them in the Directory Browser tab of the Main Control Panel. Please note that the queues are hidden root naming contexts, so you need to specifically search for them.


# Question/Answer Pair 20

Question: What are the possible capture types for Database Connectors in RadiantOne Synchronization?
Answer: The possible capture types for Database Connectors in RadiantOne Synchronization are Changelog, Timestamp, and Counter. 

1. Changelog: This connector type relies on a database table that contains all changes that have occurred on the base tables. Triggers or an external process can be used to write changes into the log/changelog table. The connector picks up changes from the changelog table.

2. Timestamp: This connector type is validated against Oracle, SQL Server, MySQL, MariaDB, PostgreSQL, and Apache Derby databases. The database table must have a primary key and an indexed column that contains a timestamp/date value. This value must be maintained and modified for each updated record. The timestamp column type varies depending on the database used.

3. Counter: This connector type is supported for any database table that has an indexed column containing a sequence-based value. The column must be one of the following types: BIGINT, DECIMAL, INTEGER, or NUMERIC. The Counter connector uses this column to determine which records have changed since the last polling interval. It can also detect delete operations if the table has a dedicated "Change Type" column indicating insert, update, or delete.

Please let me know if you need further assistance or have any other questions.


# Question/Answer Pair 22

Question: What are the possible capture connector types for Active Directory in RadiantOne Synchronization?
Answer: The possible capture connector types for Active Directory in RadiantOne Synchronization are DirSync, USNChanged, and Hybrid. 

The DirSync connector retrieves changes by passing a cookie that identifies the directory state at the time of the previous DirSync search. It stores a cookie in a cursor file when it is started and performs a DirSync search at the next polling interval to detect changes. This connector is recommended when the sequence of events is critical because it processes events in the order in which they occur.

The USNChanged connector keeps track of changes based on the uSNChanged attribute for the entry. It connects with the user and password configured in the connection string and checks the list of changes stored by Active Directory. It internally maintains the last processed change number (uSNChanged value) to recover all changes that occur, even if the connector is down.

The Hybrid connector uses a combination of the uSNChanged and DirSync change detection mechanisms. It gets a new cookie and the highest uSNChanged number when it starts. When it gets a new change, it makes an additional search using the DN of the entry and fetches the entry from AD. The fetched entry contains the uSNChanged attribute, so the connector updates the cursor values for both the cookie and the last processed uSNChanged number. This connector is suitable for virtualizing and detecting changes from a Global Catalog.

To select the desired connector type, access the Main Control Panel, Synchronization tab. Then choose the appropriate topology (on the left) and pipeline, and modify the connector type and advanced properties in the Capture component.


# Question/Answer Pair 23

Question: What is Identity Linkage used for in RadiantOne Synchronization?
Answer: Identity Linkage in RadiantOne Synchronization is used to establish a unique connection between a source identity and a target identity. This linkage can be based on a specific attribute or a combination of information computed with a function. By defining the identity linkage, you can ensure that the same logic is applied across all rules in RadiantOne Synchronization. However, if needed, each rule can have different criteria for identity linkage. The purpose of identity linkage is to accurately synchronize and match identities between different systems or data sources.


# Question/Answer Pair 24

Question: How is the Target DN generated for RadiantOne Synchronization?
Answer: The target DN for RadiantOne Synchronization can be generated automatically or manually. If you choose the Automatic option, the target DN is generated based on the virtual view created for the target and where it is mounted in the RadiantOne namespace. This option works well if you are synchronizing objects in the same container. However, if you need to sync entries into different containers or branches in the target, you should choose the Manual option.

When you select the Manual option, you will have a Target DN setting in your Rule. In this setting, you can choose the variable that contains the logic for how the target DN is generated. This allows you to have more control over the target DN generation process.

To summarize, if you want the target DN to be generated automatically based on the virtual view and mount location, choose the Automatic option. If you need more control and want to manually specify the target DN generation logic, choose the Manual option.


# Question/Answer Pair 0

Question: How do I upgrade my RadiantOne version?
Answer: To upgrade your RadiantOne version, follow this guidance:

Examples of an upgrade are moving from v7.2 to v7.3, v7.2 to v7.4, or v7.3 to v7.4. The upgrade process is not applied with an update installer and may require a professional services engagement to assess the current usage/configuration of RadiantOne to determine an appropriate upgrade strategy and time requirement. All customers currently running v7.2 and v7.3 where ICS/Synchronization is deployed should contact their Radiant Logic Account Representative to have their configuration reviewed and the scope/complexity of their upgrade path assessed. If a customer has only RadiantOne FID deployed (no ICS/Synchronization) and can upgrade their own deployment, they can leverage the upgrade guides available in the Radiant Logic Knowledge Base: [Radiant Logic Knowledge Base](<https://support.radiantlogic.com>).

1. Determine your current version: Check which version of RadiantOne you are currently using. This information will help you determine the appropriate upgrade path.

2. Access the upgrade guide: For example, you can find the upgrade guide for upgrading from version 7.2 to 7.4 at this link: [RadiantOne Upgrade Guide v7.2 to v7.4](<https://support.radiantlogic.com/hc/en-us/articles/7908444062612-RadiantOne-Upgrade-Guide-v7-2-to-v7-4>). This guide provides step-by-step instructions on how to perform the upgrade.

3. Contact your Radiant Logic Account Representative: If you are using version 7.2 or 7.3 and require upgrade assistance, please reach out to your Radiant Logic Account Representative. They will be able to provide guidance and support for your specific upgrade needs.

Remember to always backup your data before proceeding with any upgrades to ensure the safety of your information. If you have any further questions or need additional assistance, feel free to ask.


# Question/Answer Pair 1

Question: How does RadiantOne address challenges for implementing Zero Trust Architecture?
Answer: The identity system continues to decentralize and grow in complexity and volume, making it increasingly difficult for IT and security teams to combat cyber threats. Security control points are increasingly decentralized, but require real-time access to dispersed identity data to execute policies. Correlating and delivering that necessary data in the format required by each policy enforcement point is a prerequisite to Zero Trust Architecture. Implementation of practices like attribute-based access control requires a high-quality and rich set of information about each user to enforce security policy.
Identity-based controls are the modern way to secure the organization: but the hidden challenge is often delivering the identity data they require from across a complex infrastructure. Many organizations are dealing with identity sprawl:
• Identity data, including attributes for enforcing authorization, is dispersed
• Identity data might be stale, incomplete, or duplicative
RadiantOne addresses the requirement for access to high-quality identity data, delivering the required user context so that security policies can be precise.
• To deliver granular access control, complete and clean identity data is required
• Fine-grained authorization relies on access to detailed identity data
RadiantOne addresses identity complexity with integration, to:
• Deliver identity data that is: consistent, context-aware, and continuous
• Speed attribute-based access control with a unified source of identity data
• Reduce risk by implementing fine-grained authorization with many attributes
• Streamline compliance and audit with a 360-degree view of identity
• Decrease the attack surface, limit lateral movement, and prevent fraud


# Question/Answer Pair 3

Question: How do I initialize a RadiantOne Directory store replica in another RadiantOne Cluster?
Answer: To initialize a RadiantOne Directory store replica in another RadiantOne Cluster, follow these steps:

1. Determine the leader node of the cluster by going to the Dashboard tab of the Main Control Panel. Look for the node marked as the leader (with a gold triangle).
2. If there are multiple clusters involved, export an LDIF file from the cluster considered the "master" image. Make sure the “Export for replication” option is enabled during the LDIF export.
3. Disable inter-cluster replication for the RadiantOne Directory store if you plan on re-initializing all replicas with a clean image. If you want to maintain inter-cluster replication and process changes from other replicas while re-initializing, do not disable inter-cluster replication.
4. Make sure to schedule a maintenance window for the re-initialization process, as it is time-consuming and requires the service to be offline.
5. On the Main Control Panel, go to the Directory Namespace tab and select the RadiantOne Directory store you want to initialize.
6. Click on the Initialize button on the Properties Tab.
7. Browse to the desired LDIF file and select it.
8. The initialization process will be executed on the leader node. The store on the leader node will be initialized and then activated again. The data will be copied to all follower/follower-only nodes.
9. If you have a large data set and multiple LDIF files, name the files with a suffix of "_2", "_3", etc., and make sure they are located in the same place for the initialization process to find them.

Please note that these instructions assume you are initializing the store on the leader node. If you attempt to initialize on a non-leader node, you will receive an error message indicating that you must perform this operation on a leader node.

Let me know if you need further assistance!


# Question/Answer Pair 0

Question: What LDAP controls and extensions are supported by RadiantOne?
Answer: RadiantOne supports several LDAP controls and extensions. Here is a list of the controls and extensions supported by RadiantOne 7.4:

1. Subtree Delete Control - 1.2.840.113556.1.4.805
2. Password expired notification control - 2.16.840.1.113730.3.4.4
3. Password expiring notification control - 2.16.840.1.113730.3.4.5
4. Password policy control - 1.3.6.1.4.1.42.2.27.8.5.1
5. Persistent search control - 2.16.840.1.113730.3.4.3
6. Virtual list view request control - 2.16.840.1.113730.3.4.9
7. Proxied authorization (version 2) control - 2.16.840.1.113730.3.4.18
8. Server-side sort request - 1.2.840.113556.1.4.473
9. Authorization bind identity response control - 2.16.840.1.113730.3.4.15
10. Authorization bind identity request control - 2.16.840.1.113730.3.4.16
11. Who Am I extended operation - 1.3.6.1.4.1.4203.1.11.3
12. Paged Results Control - 1.2.840.113556.1.4.319
13. Dynamic entries extension - 1.3.6.1.4.1.1466.101.119.1
14. All Operational Attributes feature - 1.3.6.1.4.1.4203.1.5.1
15. Absolute True and False Filters - 1.3.6.1.4.1.4203.1.5.3

Please note that RadiantOne does not support the following controls used in Sun Java Directory/ODSEE:

1. Manage DSA IT control - 2.16.840.1.113730.3.4.2
2. Get effective rights request control - 1.3.6.1.4.1.42.2.27.9.5.2
3. Account usability control - 1.3.6.1.4.1.42.2.27.9.5.8
4. Specific backend search request control - 2.16.840.1.113730.3.4.14
5. Real attributes only request control - 2.16.840.1.113730.3.4.17
6. Virtual attributes only request control - 2.16.840.1.113730.3.4.19

To enable controls like Paged Results, VLV/Sort, Persistent Search, and Proxy Authorization, you can go to the Main Control Panel, then navigate to the Settings tab and select Server front end. From there, you can find the Supported Controls section.

Is there anything else I can help you with?


# Question/Answer Pair 1

Question: Which LDAP protocol versions does RadiantOne v7.4 support?
Answer: RadiantOne supports LDAP protocol versions 2 and 3. The information about the supported LDAP protocol versions can be found by querying the supportedldapversion attribute in the rootDSE entry.


# Question/Answer Pair 0

Question: How to fix Spring vulnerability spring-core-5.3.8.jar?
Answer: To fix the Spring vulnerability related to the spring-core-5.3.8.jar, you need to follow these steps:

1. Disable the "docs" and "openid" web applications: These webapps are optional and do not affect RadiantOne functionality. You can safely disable them by moving the .war files for each webapp (docs.war and openid.war) to the RLI_HOME/apps/web/disabled folder.

2. Remove associated folders: After disabling the web applications, you should remove the following folders:
   - \&lt;RLI_HOME\&gt;/vds_server/work/docs
   - \&lt;RLI_HOME\&gt;/vds_server/work/openid

3. Restart the Control Panel on all nodes in the cluster: After moving the .war files and removing the folders, you need to restart the Control Panel on all nodes in the cluster to apply the changes.

Please note that these steps are specific to addressing the Spring vulnerability and do not impact the functionality of RadiantOne.

If you have any further questions or need additional assistance, please let me know.


# Question/Answer Pair 1

Question: Why is RadiantOne so buggy?
Answer: RadiantOne is a software product that undergoes regular updates and bug fixes to improve its performance and address any issues that may arise. The presence of bugs in software is not uncommon, and the RadiantOne development team works diligently to identify and resolve them.

To address any specific issues you may be experiencing, it would be helpful to know which version of RadiantOne you are using. The release notes for each version provide information about the improvements and bug fixes included in that particular release.

If you are experiencing a specific issue that is not addressed in the release notes, please provide more details about the problem you are facing, and I will do my best to assist you further.


# Question/Answer Pair 0

Question: How to change the cluster name?
Answer: To change the cluster name of RadiantOne v7.4, please follow these step-by-step instructions:

Please note that renaming a cluster is a delicate operation and should not be used frequently. It is also not recommended for deployed architectures involved in inter-cluster replication, as the cluster name is crucial for replication logic.

1. Stop all RadiantOne services except ZooKeeper.
2. On any RadiantOne node, run the following command:
   `&lt;RLI_HOME&gt;/bin/advanced/cluster.sh rename-cluster-zk &lt;vds_instance_name&gt; &lt;old_cluster_name&gt; &lt;new_cluster_name&gt;`
   This command will move the ZooKeeper data from `/radiantone/v2/&lt;old_cluster_name&gt;` to `/radiantone/v2/&lt;new_cluster_name&gt;`.
3. On each RadiantOne node, run the following command:
   `&lt;RLI_HOME&gt;/bin/advanced/cluster.sh rename-cluster-local &lt;vds_instance_name&gt; &lt;new_cluster_name&gt;`
4. Start RadiantOne services (e.g., FID, Control Panel (Jetty), etc.) on all nodes.


Let me know if you need any further assistance!


# Question/Answer Pair 2

Question: How to use Eclipse in RadiantOne v7.4?
Answer: To use Eclipse in RadiantOne v7.4, please follow these step-by-step instructions:

1. Install Eclipse IDE for Java developers.
2. Launch Eclipse and choose File -&gt; Import.
3. Expand the General folder, select Existing Projects into Workspace, and click Next.
4. Click Browse next to Select Root Directory and navigate to &lt;RLI_HOME&gt;/vds_server/custom.
5. Click Finish.
6. Navigate below the Custom folder to src.com.rli.scripts.intercept. The scripts associated with the interceptions will appear below. Double-click on the script to open it in the Eclipse IDE editor.
7. Edit the script.
8. Save the script.
9. On the RadiantOne machine, rebuild the intercept.jar with ANT using the following syntax:
   ```
   C:\radiantone\vds\vds_server\custom&gt;c:\radiantone\vds\ant\bin\ant.bat buildjars
   ```
10. Restart the RadiantOne service. If deployed in a cluster, restart it on all nodes.

Please let me know if you need further assistance or have any other questions!


# Question/Answer Pair 1

Question: What is rli_router used for in RadiantOne?
Answer: The RadiantOne Access Router can be used in test environments where a hardware load balancer is not available. It was deprecated as of v7.3. In older versions of RadiantOne, it was used for load balancing or failover between multiple directories that contain the same structure. The directories could be virtual directories or any other LDAP-accessible server.

The access router works at the "packet" level, adding very little overhead to the system. It is an excellent way to aggregate throughput from many different servers, with the increase in throughput being linear up to about 10 LDAP servers. Any constraint in throughput is essentially linked to the processing and bandwidth of the machine where the router is running. Therefore, it is recommended to install the router on a machine where both bandwidth connectivity and processing can be dedicated to achieve the full benefits and performance.

All configuration information for the RadiantOne Access Router is stored in the `&lt;RLI_HOME&gt;/rlirouter/rli_router.conf` file, which is managed from the Router Administration Console.

The access router manages failover and load balancing at the level of the connection, not the operation. In a failover configuration, when a client establishes a connection, all operations are sent to the primary server. If an operation fails due to a loss of connection to the underlying LDAP server, the failover happens when the client re-opens the connection. The existing operation isn't automatically sent to the failover server. Only when the client re-connects will the connection be sent to the failover server.

During load balancing, all operations issued under the same connection are sent to the same underlying LDAP server. If a client application opens two connections, then one connection is sent to each underlying LDAP server.

Please let me know if there is anything else I can assist you with.


# Question/Answer Pair 0

Question: what is the unit of the ETIME column in the RadiantOne server logs?
Answer: The ETIME column in the server logs measures the time taken for a request to be processed. The unit of measurement for this column is milliseconds (ms). So, when you see a value in the ETIME column, it represents the time taken in milliseconds for that particular request to be processed.

If you have any further questions or need assistance with anything else, please let me know.


# Question/Answer Pair 3

Question: is there way to determine what cipher key is being used during the TLS handshake with RadiantOne v7.4 during the initial simple binding with SSL?
Answer: To determine the cipher key being used during the TLS handshake, you can follow these steps:

1. Open the RadiantOne Main Control Panel.
2. Go to the Settings tab and click on Security.
3. Under the SSL section, click on the Change button next to Supported Cipher Suites.
4. A list of cipher suites will be displayed, indicating the available options for encryption during the TLS handshake.

I hope this helps! Let me know if you have any further questions or need more assistance.


# Question/Answer Pair 4

Question: What does the Global Identity Builder do?
Answer: The Global Identity Builder is a tool that creates a unified list of identities from different sources, even if they don't have a single attribute as an overlapping common identifier. This tool is useful when applications need to authenticate users or access their complete profiles for authorization purposes. It can handle situations where there are overlapping users or when a complete aggregated list of users is needed. The Global Identity Builder also allows for the remapping of information into the format expected by the application. To learn more about how to use the Global Identity Builder, please refer to the RadiantOne Global Identity Builder Guide.


# Question/Answer Pair 5

Question: Where can I find the LDIF data analysis tool in RadiantOne v7.4?
Answer: The LDIF data analysis tool can be found in the \&lt;RLI_HOME\&gt;/bin/advanced directory. On Windows, it is named data_analysis.bat, and on Linux, it is named data_analysis.sh. To use the tool, you need to run it from a command prompt and provide the necessary arguments.

The required arguments are:
-d: The report directory where the report files will be saved. The report directory should not contain any path characters (/,\).
-f: The full name of the LDIF file you want to analyze. You can include the file path if needed.

Optional arguments are:
-h: Displays the help information.
-o: Allows you to overwrite files in the report directory. If you don't pass this option and the report directory already exists, no analysis will be done, and the report directory's files will not be changed.
-r: Removes detailed analysis files in the report directory.

Here's an example command to run the LDIF data analysis tool:
C:\radiantone\vds\bin\advanced\&gt;data_analysis.bat -d LDAPANALYSIS -f "C:\radiantone\vds\vds_server\ldif\export\ldap.ldif"

After running the tool, the reports will be generated in the specified report directory. In this example, the reports will be located in the following directory: C:\radiantone\vds\r1syncsvcs\profiler\LDAPANALYSIS.


# Question/Answer Pair 0

Question: How do I provision Active Directory users into Entra ID?
Answer: To provision Active Directory users into Entra ID, follow these steps:

1. First, create an application in Entra ID. Go to the Entra ID portal, click on Manage -&gt; App Registrations and then the New Registration button. Provide a name for the application and select the option for “Accounts in this organizational directory only” for the Supported Account Types. After registering, take note of the Application ID.

2. Navigate to Certificates &amp; Secrets and click New Client Secret. Enter a description, expiration and click Add. Take note of the secret key value displayed.

3. Navigate to API Permissions and click Add a Permission. Enable Directory.Read.All for read-only access. If you want read/write access to the data, enable the Directory.ReadWrite.All access. Click Add Permissions and then click Grant Admin Consent.

4. Update the mgraph in RadiantOne v7.4. From the Main Control Panel, go to the Settings tab. Under the Server Backend section, find Custom Data Sources. Select 'mgraph' and click on the clone icon. Enter a new data source name (for example, 'mgraphupdated') and click 'Clone'. A confirmation message will appear. Click 'OK' to exit. Now, select the new custom data source you just created ('mgraphupdated') and click on the edit icon. Here, you can enter the properties needed to connect to the applicable tenant.

5. Enter the value of the Entra ID Application ID for the username property and the password key for the password property. Enter the URL for your Azure AD tenant for the oauthurl property and set the active property to true.

7. Edit the default virtual view for Azure AD in RadiantOne to point to your Azure AD custom data source. Launch RadiantOne Context Builder and select the View Designer perspective. Choose File -&gt; Open -&gt; View. Select the mgraph view and click OK. Save the view with a new file name.

8. On the Tree View tab, right-click on the view name and choose Edit Connection String. Select the custom data source created earlier and click OK.

9. In the RadiantOne Main Control Panel, go to the Directory Namespace tab. Enter a naming context and select the Virtual Tree type. Select the virtual view created in Context Builder and click OK.

10. Finally, select the Main Control Panel -&gt; Directory Browser tab and click to re-load the tree. Navigate to the root naming context created earlier. Expand the tree and verify your Azure AD user and groups are returned.


# Question/Answer Pair 0

Question: Where do I find the Data Sources perspective in RadiantOne v7.4, Context Builder tool?
Answer: Starting in RadiantOne v7.4, Data Sources are managed from the Control Panel. To access the Data Sources in RadiantOne v7.4 and later versions, follow these steps:
1. Open the Control Panel.
2. Go to the "Settings" tab.
3. Select "Server Backend".

From the Server Backend section in the Control Panel, you can manage your Data Sources.


# Question/Answer Pair 2

Question: What is Environment Operations Center?
Answer: The Environment Operations Center is a tool that allows you to control your RadiantOne environment for SaaS deployments. It provides all the necessary tools to create, manage, and monitor your RadiantOne environments. You can refer to the guide at <https://developer.radiantlogic.com/idm/v8.0/environment-operations-center-guide/overview/> for more details. This guide will give you an overview of the Environment Operations Center home screen and how to navigate the interface.


# Question/Answer Pair 0

Question: How do I update the external ZooKeeper being used by RadiantOne 7.4?
Answer: To update external ZooKeeper which new patches provided by Radiant Logic, please follow these step-by-step instructions:

1. Copy the "rli-zookeeper-external\*" file to each of your ZooKeeper servers.
2. Unzip the new ZooKeeper version in a separate, temporary folder (other than the one it is currently installed on).
3. Stop ZooKeeper on the node you are updating.
4. If you haven't already done so, make a copy/backup of the existing ZooKeeper home location.
5. Copy the following folders from the new version (that you unzipped in step 2) to the existing setup:
   - /bin/ (copy)
   - /setup/ (remove from target first – remove all jars, then copy)
   - /zookeeper/bin/ (remove from target first, then copy)
   - /zookeeper/docs/ (remove from target first, then copy)
   - /zookeeper/lib/ (remove from target first, then copy)
   - /jdk/ (remove from target first, then copy)
6. Delete the temporary folder that you unzipped the new ZooKeeper version to in step 2.
7. Start ZooKeeper.
8. Repeat the steps above for each ZooKeeper server in your external ensemble.

Please note that the truststore and keystore are created when ZooKeeper is restarted after the update. If you want to use SSL/TLS access to ZooKeeper, ensure you have imported the required certificates. For steps, please refer to the RadiantOne Hardening Guide.


# Question/Answer Pair 0

Question: Can RadiantOne v7.4 be deployed on Kubernetes?
Answer: the correct answer is: Yes, RadiantOne v7.4 can be deployed on a Kubernetes cluster. See this for more information: 
<https://developer.radiantlogic.com/idm/v7.4/getting_started/kubernetes/>


# Question/Answer Pair 3

Question: How do I configure SSL connectivity between RadiantOne v7.4 and ZooKeeper?
Answer: To configure SSL connectivity between RadiantOne v7.4 and ZooKeeper, you can refer to the "Configuring SSL between FID and ZooKeeper" section in the RadiantOne Hardening Guide. This guide provides step-by-step instructions on how to configure SSL between RadiantOne and ZooKeeper.

If you need further assistance or have any other questions, feel free to ask!


# Question/Answer Pair 1

Question: Why is the RadiantOne v7.4 service not returning the memberOf attribute for queries on user entries?
Answer: To ensure the RadiantOne v7.4 service is able to return the computed back-link attribute memberOf for user entries, follow the guidance below.

Configure Linked Attributes for memberOf following the guidance here: <https://developer.radiantlogic.com/idm/v7.4/sys-admin-guide/interception/#linked-attributes>


Additionally, if you want to search for group membership using an LDAP filter, you can use the LDAP_MATCHING_RULE_IN_CHAIN OID. The example filter provided in the documents is:
(uniquemember:1.2.840.113556.1.4.1941:=uid=Ada_Rule,ou=Administration,o=companydirectory)

You can use this filter to query RadiantOne for a list of all groups a user is a member of.

Please let me know if you need further assistance or if there's anything else I can help you with.


# Question/Answer Pair 2

Question: Is the wizards tab accessible from the Main Control Panel on Follower nodes of a cluster in RadiantOne 7.4?
Answer: The wizards tab is not accessible on follower nodes of a cluster in RadiantOne v7.4. The wizards tab is only available in the leader node of the cluster. The leader node is responsible for managing the configuration and changes in the cluster. Follower nodes, on the other hand, replicate the changes made by the leader node.

To access the wizards tab, you need to log in to the leader node of the cluster. Once logged in, you can navigate to the Main Control Panel and find the wizards tab. From there, you can access and use the various wizards available for configuration and setup.

Please let me know if you have any further questions or if there's anything else I can assist you with.


# Question/Answer Pair 13

Question: what is the role of sync engine in RadiantOne v7.4?
Answer: The role of the Sync Engine in RadiantOne v7.4 is to process attribute mappings and transformation scripts before sending events to the target endpoints. It acts as the central component that coordinates the synchronization process.

When changes occur in the data sources, the Sync Engine receives these changes from the queues. It then applies the necessary attribute mappings and transformation scripts to format the data correctly for the target endpoints. Once the data is transformed, the Sync Engine sends the events to the target endpoints for further processing.

The Sync Engine ensures that the synchronization process is efficient and accurate by handling the mapping and transformation of data. It plays a crucial role in maintaining data consistency and integrity between different systems.


# Question/Answer Pair 1

Question: How to setup MFA for the Control Panel in RadiantOne v7.4?
Answer: MFA handling is delegated to the Identity Provider configured for authenticating users for the RadiantOne Control Panel. OIDC is supported and configuration steps are outlined here: <https://developer.radiantlogic.com/idm/v7.4/sys-admin-guide/01-introduction/#openid-connect-token-authentication>

I hope this helps! Let me know if you have any further questions or need additional assistance.


# Question/Answer Pair 2

Question: Does RadiantOne use the Apache Xalan Java XSLT library and Apache Batik?
Answer: RadiantOne does use these two libraries Apache Xalan Java XSLT and Apache Batik within the product. Apache Batik library is used for some of our report generation and Apache Xalan is used for XML processing.