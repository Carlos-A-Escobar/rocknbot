from bonito import Bonito
from vllm import SamplingParams
from datasets import load_dataset, Dataset
from llama_index.core import Document
import os
import random
import lancedb
from deepeval.synthesizer import Synthesizer
from dotenv import dotenv_values
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding

rag_env = dotenv_values("rag.env")
OPENAI_API_KEY = rag_env["OPENAI_API_KEY"]
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')

# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="sentence-transformers/all-MiniLM-L6-v2"
# )

db = lancedb.connect("./lancedb")
table = db.open_table('hierarchical_OpenAI_RL')

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)
retriever = index.as_retriever(similarity_top_k = 80)

nodes = retriever.retrieve("guide")
text = [node.node.text for node in nodes]
# random_nodes = random.sample(nodes, 80)

dataset = Dataset.from_file


bonito = Bonito("BatsResearch/bonito-v1")

sampling_params = SamplingParams(max_tokens=256, top_p=0.95, temperature=0.5, n=1)
synthetic_dataset = bonito.generate_tasks(
    text,
    context_col='input',
    task_type='nli',
    sampling_params=sampling_params
)

print('hi')