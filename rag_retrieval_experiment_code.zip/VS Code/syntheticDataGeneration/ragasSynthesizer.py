import os
import pandas as pd
from dotenv import dotenv_values
from langchain_community.document_loaders import DirectoryLoader
from ragas.testset.generator import TestsetGenerator
from ragas.testset.evolutions import simple, reasoning, multi_context
import os
import random
import lancedb
from openai import OpenAI
from dotenv import dotenv_values
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings, Document
from llama_index.embeddings.openai import OpenAIEmbedding
import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings, Document
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.node_parser import MarkdownNodeParser
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
client = OpenAI_Llama()
client = OpenAI()

# Define the directories
directories = [
    './docs/7.4',
    './docs/8.0',
    './docs/8.1',
    './docs/eoc-latest',
    './docs/ia-product-descartes',
    './docs/ia-product-descartes-dev',
    './docs/ia-selfmanaged-1.5',
    './docs/identity-analytics-iap-2.2'
]

# Function to get all .md files in a directory recursively
def find_md_files(directory):
    md_files = []
    for root, dir, files in os.walk(directory):
        for file in files:
            if file.endswith(".md"):
                md_files.append(os.path.join(root, file))
    return md_files

def extract_metadata_from_lines(lines):
    metadata = {}
    for line in lines:
        if line.startswith('title:'):
            metadata['title'] = line.split(':', 1)[1].strip()
        elif line.startswith('description:'):
            metadata['description'] = line.split(':', 1)[1].strip()
        elif line.startswith('keywords:'):
            metadata['keywords'] = line.split(':', 1)[1].strip()
    return metadata

# Initialize model and pipeline
node_parser = MarkdownNodeParser()
reader = MarkdownReader()
file_extractor = {".md": reader}
Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")

all_docs = []


for directory in directories:
    version = os.path.basename(directory)

    md_files = find_md_files(directory)

    for file in md_files:
        with open(file, 'r', encoding='utf-8') as f:
            first_lines = []
            for _ in range(5):
                try:
                    first_lines.append(next(f).strip())
                except StopIteration:
                    break

        metadata = extract_metadata_from_lines(first_lines)
        metadata["version"] = version
        metadata["product_tag"] = "IDDM"

        documents = SimpleDirectoryReader(
            input_files=[file], file_extractor=file_extractor
        ).load_data()
        for doc in documents:
            for label in metadata:
                doc.metadata[label] = metadata[label]
        all_docs.extend(documents)

final_docs = []

for doc in all_docs:
    if len(doc.text) > 1000:
        final_docs.append(doc)

final_docs = random.sample(final_docs, k=15)

generator_llm = OpenAI_Llama(model="gpt-3.5-turbo")
critic_llm = OpenAI_Llama(model="gpt-3.5-turbo")
embeddings = OpenAIEmbedding(model="text-embedding-3-large")

generator = TestsetGenerator.from_llama_index(
    generator_llm,
    critic_llm,
    embeddings
)

# generate testset
testset = generator.generate_with_llamaindex_docs(documents=final_docs, test_size=10, distributions={multi_context: 1.0})
test_df = testset.to_pandas()

test_df.to_excel('good_results/add2.xlsx', index=False)