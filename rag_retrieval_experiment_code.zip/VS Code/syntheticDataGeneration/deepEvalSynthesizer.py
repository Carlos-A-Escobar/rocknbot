import os
import random
import lancedb
from deepeval.synthesizer import Synthesizer
from dotenv import dotenv_values
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding

rag_env = dotenv_values("rag.env")
OPENAI_API_KEY = rag_env["OPENAI_API_KEY"]
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

synthesizer = Synthesizer()

directories = [
    './docs/7.4',
    './docs/8.0',
    './docs/8.1',
    './docs/eoc-latest',
    './docs/ia-product-descartes',
    './docs/ia-product-descartes-dev',
    './docs/ia-selfmanaged-1.5',
    './docs/identity-analytics-iap-2.2'
]

# Settings.embed_model = HuggingFaceEmbedding(
#     model_name="BAAI/bge-large-en-v1.5"
# )

# # Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')


# db = lancedb.connect("./lancedb_SQUAD")
# table = db.open_table('BGE')
# vector_store = LanceDBVectorStore.from_table(table)
# index = VectorStoreIndex.from_vector_store(vector_store)
# retriever = index.as_retriever(similarity_top_k = 100)
# nodes = retriever.retrieve("A computational problem can be viewed")



# Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')
# table2 = db.open_table('OpenAI')
# vector_store2 = LanceDBVectorStore.from_table(table2)
# index2 = VectorStoreIndex.from_vector_store(vector_store2)
# retriever2 = index2.as_retriever(similarity_top_k = 100)
# nodes2 = retriever2.retrieve("A computational problem can be viewed")

# if len(nodes) > 80:
#     nodes = random.sample(nodes, 80)

# chunks = []
# ids = []
# for node in nodes:
#     chunks.append([node.node.text])
#     ids.append(node.id_)
# num_questions = 60 // len(chunks) + 1

# synthesizer.generate_goldens(
#     contexts=chunks,
#     source_files=ids,
#     max_goldens_per_context=num_questions,
#     num_evolutions=5,
#     include_expected_output=False
# )



md_files = []
for directory in directories:
    for root, dir, files in os.walk(directory):
        for file in files:
            if file.endswith(".md"):
                md_files.append(os.path.join(root, file))

synthesizer.generate_goldens_from_docs(
    document_paths=files_list,
    include_expected_output=True,
    max_goldens_per_document=6,
    chunk_size=2048,
    num_evolutions=5
)

synthesizer.save_as(
    file_type='json',
    directory="./synthetic_data_new/hierarchical_SQUAD/"
)