import os
import lancedb
from gliner import GLiNER
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex, Document
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.extractors import SummaryExtractor, QuestionsAnsweredExtractor
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from lancedb.embeddings import get_registry
from llama_index.core.schema import TextNode
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

import pandas as pd
from datasets import load_dataset
from tqdm import tqdm

# Load the SQuAD v2 validation dataset
squad_dev = load_dataset('squad_v2', split='validation')

# Convert the dataset to a DataFrame
squad_data = []
for row in tqdm(squad_dev):
    squad_df = squad_data.append({
        'question': row['question'],
        'context': row['context'],
        'id': row['id']
    })

squad_df = pd.DataFrame(squad_data)

# Drop duplicate contexts and modify IDs
no_dupe = squad_df.drop_duplicates(subset='context', keep='first')
no_dupe = no_dupe.drop(columns=['question'])
no_dupe['id'] = no_dupe['id'] + 'con'

# Merge the modified DataFrame with the original
squad_df = squad_df.merge(no_dupe, how='inner', on='context')

# Create the IR queries and corpus
ir_queries = {row['id_x']: row['question'] for i, row in squad_df.iterrows()}
ir_corpus = {row['id_y']: row['context'] for i, row in squad_df.iterrows()}

# Create the relevant docs mapping
ir_relevant_docs = {key: [] for key in squad_df['id_x'].unique()}
for i, row in squad_df.iterrows():
    ir_relevant_docs[row['id_x']].append(row['id_y'])
ir_relevant_docs = {key: set(values) for key, values in ir_relevant_docs.items()}

nodes = []

for con_id in ir_corpus:
    context = ir_corpus.get(con_id)
    node = TextNode(text=context, id_=con_id)
    nodes.append(node)

Settings.embed_model = OpenAIEmbedding(model_name='text-embedding-3-large')
vector_store = LanceDBVectorStore(uri="./lancedb_SQUAD", table_name="OpenAI", query_type="hybrid")
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex(nodes=nodes, storage_context=storage_context)

Settings.embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en-v1.5")
vector_store2 = LanceDBVectorStore(uri="./lancedb_SQUAD", table_name="BGE", query_type="hybrid")
storage_context2 = StorageContext.from_defaults(vector_store=vector_store2)
index2 = VectorStoreIndex(nodes=nodes, storage_context=storage_context2)