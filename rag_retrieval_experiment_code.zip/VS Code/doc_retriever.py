import os
import lancedb
import copy
import openai
import tiktoken
from llama_index.core import SimpleDirectoryReader, StorageContext, VectorStoreIndex
from llama_index.core.node_parser import HierarchicalNodeParser
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.llms import ChatMessage
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.node_parser import get_leaf_nodes
from llama_index.core import Settings, Document
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.node_parser import MarkdownNodeParser, SentenceSplitter
from llama_index.readers.file import MarkdownReader
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from lancedb.embeddings import get_registry
from llama_index.llms.bedrock import Bedrock
from botocore.exceptions import ClientError
import boto3
import nest_asyncio

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information and without the use of prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.
    2. Avoid statements like 'Based on the context, ...' or 'The context information ...' or anything along those lines.
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Answer ALL parts of the user's query.ss
    5. Do not justify your answers.
    6. Do not restate questions or suggestions in your answer.
    7. Do not include extraneous symbols, tags, or prefixes.
    8. Do not add seemingly useless information once you have successfully answered the user's query.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ----------------------------------------------------\n
    {context_str}\n
    ----------------------------------------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

os.environ["OPENAI_API_KEY"] = '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'
CLIENT = boto3.client(
        service_name="bedrock-runtime", 
        region_name="us-west-2", 
        aws_access_key_id="AKIA2QETGWXF2YG2MP2G", 
        aws_secret_access_key="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"
    )
model_id = "meta.llama3-1-70b-instruct-v1:0"
user_msg = QA_USER_PROMPT.format(context_str="carlos favorite food is crawfish", query_str="what is carlos favorite food?")
conversation = [
    {
        "role": "user",
        "content": [{"text": user_msg}]
    }
]
try:
    response = CLIENT.converse(
        modelId=model_id,
        messages=conversation,
        system=[{"text": QA_SYSTEM_PROMPT}],
        inferenceConfig={"maxTokens": 1000},
    )
    response_text = response["output"]["message"]["content"][0]["text"]
    print(response_text)
except (ClientError, Exception) as e:
    print(f"ERROR: Can't invoke '{model_id}'. Reason: {e}")
    exit(1)

print('done')
class DocumentRetriever:
    def __init__(self, table_name = "IDDM"):
        Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
        db = lancedb.connect("./lancedb")
        table = db.open_table(table_name)
        vector_store = LanceDBVectorStore.from_table(table)
        index = VectorStoreIndex.from_vector_store(vector_store)
        self.retriever = index.as_retriever(similarity_top_k=30)
        self.reranker = SentenceTransformerRerank(top_n=30, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
    
    def retrieve(self, query):
        nodes = self.retriever.retrieve(query)
        reranked_nodes = self.reranker.postprocess_nodes(nodes=nodes, query_str=query)[:5]
        self.synthesize_answer(query, reranked_nodes)
    
    def synthesize_answer(self, query, nodes):
        formatted_context = "\n\n".join(node.text for node in nodes)
        print(formatted_context)
        
doc_retriever = DocumentRetriever()
doc_retriever.retrieve("what is the unit type of etime in fid logs?")
