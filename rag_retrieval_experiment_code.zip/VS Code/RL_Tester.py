import os
import json
import lancedb
import time
import nest_asyncio
import numpy as np
from openai import OpenAI
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings
from llama_index.core import StorageContext
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
nest_asyncio.apply()

client = OpenAI()

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide step-by-step instructions and clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information, 
    and not prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.\n
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.\m
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Do not justify your answers.
    5. Do not restate questions or suggestions in your answer.
    6. Do not include extraneous symbols, tags, or prefixes.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

def get_nodes(retriever, question):
        nodes = retriever.retrieve(question)

        first_half = nodes[:40]
        second_half = nodes[40:]
        reranked_nodes = reranker.postprocess_nodes(first_half, query_str=question)

        split1 = reranked_nodes[:5]
        split2 = reranked_nodes[5:]
        reranked_nodes2 = reranker2.postprocess_nodes(split1, query_str=question)

        combined_nodes = reranked_nodes2 + split2
        final_nodes = combined_nodes + second_half
        # final_nodes = reranked_nodes + second_half
        return final_nodes


reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)

db = lancedb.connect("./lancedb_new")

# table = db.open_table("docs")
# Settings.embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en-v1.5")

table = db.open_table("docs_OpenAI_hierarchical")
# table = db.open_table("docs_OpenAI")
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)

retriever = index.as_retriever(similarity_top_k=30)

query = 'What are computed attributes used for?'

start_time = time.time()


st1 = time.time()
auto_nodes = retriever.retrieve(query)
et1 = time.time() - st1

print(et1)

st2 = time.time()
reranked_nodes2 = reranker.postprocess_nodes(auto_nodes, query_str=query)
et2 = time.time() - st2

st3 = time.time()
final_nodes2 = reranker2.postprocess_nodes(reranked_nodes2, query_str=query)
et3 = time.time() - st3


elapsed_time = time.time() - start_time

second_half = reranked_nodes2[5:]
first_half = reranked_nodes2[:5]
final_nodes3 = reranker2.postprocess_nodes(first_half, query_str=query)
combined_nodes = final_nodes3 + second_half

rank_dict1 = {node.id_: rank for rank, node in enumerate(auto_nodes, start=1)}
rank_dict2 = {node.id_: rank for rank, node in enumerate(reranked_nodes2, start=1)}
rank_dict3 = {node.id_: rank for rank, node in enumerate(final_nodes2, start=1)}
rank_dict4 = {node.id_: rank for rank, node in enumerate(combined_nodes, start=1)}

# Find common node IDs in both lists
common_ids = set(rank_dict1.keys())

# Compare the ranks and store the results for common nodes only
rank_comparison = {
    node_id: (rank_dict1[node_id], rank_dict2[node_id], rank_dict3[node_id], rank_dict4[node_id]) for node_id in common_ids
}

print("QUESTION: " + query)
for node in auto_nodes:
    print()
    print("------------------------------------------------")
    print("HYBRID RANK: " + str(rank_dict1[node.id_]) + ",   CROSSENCODER RANK: " + str(rank_dict2[node.id_]) + ",   COLBERT RANK: " + str(rank_dict3[node.id_]) + ",   BOTH RANK: " + str(rank_dict4[node.id_]))
    print()
    print(node.text)
    print("------------------------------------------------")
    print()

total_time = 0

with open("qa_pairs.json", 'r') as file:
    question_num = 1
    data = json.load(file)
    for entry in data:
        if "question" not in entry:
            break
        print("\n" + str(question_num))
        question_num += 1

        question = entry['question']
        print("\nQuestion: " + question)
        st1 = time.time()
        nodes = retriever.retrieve(question)[:5]
        et1 = time.time()

        total_time += (et1 - st1)

        chunks = ""
        for node in nodes:
            chunks += node.text
            # chunks += "\n\n"
        entry['retrieval_context_hybrid_md'] = chunks
        prompt = QA_USER_PROMPT.format(context_str=chunks, query_str=question)
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": QA_SYSTEM_PROMPT},
                {"role": "user", "content": prompt}
            ]
        )
        answer = entry['answer']
        generated_answer = response.choices[0].message.content

        print("\nAnswer: " + answer)
        print("\nGenerated Answer: " + generated_answer)
        entry['output_hybrid_md'] = generated_answer
    
    data.append({
        "Time_Hybrid_md": total_time
    })

with open('qa_pairs.json', 'w') as file:
    json.dump(data, file, indent=4)  # Write the updated data back to the file with proper indentation


# # Initialize the dictionary with the specified keys and set initial scores to 0
# version_scores = {
#     "8.1": 0,
#     "8.0": 0,
#     "7.4": 0,
#     "eoc-latest": 0,
#     "ia-product-descartes": 0,
#     "ia-product-descartes-dev": 0,
#     "ia-selfmanaged-1.5": 0,
#     "identity-analytics-iap-2.2": 0
# }

# # Update the scores based on the nodes' metadata
# for node in nodes:
#     version = node.metadata.get('version')
#     if version in version_scores:
#         version_scores[version] += 1

# print(version_scores)
# print('done')