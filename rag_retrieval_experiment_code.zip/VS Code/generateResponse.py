import os
import json
import pandas as pd
import nest_asyncio
import lancedb
from openai import OpenAI
from llama_index.readers.file import MarkdownReader
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core import VectorStoreIndex, Settings, StorageContext, SimpleDirectoryReader
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
from deepeval.metrics import AnswerRelevancyMetric, ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase
from ragas.testset.generator import TestsetGenerator
from ragas.testset.evolutions import simple, reasoning, multi_context
from llama_index.llms.openai import OpenAI as OpenAI_Llama
import pandas as pd
from datasets import Dataset

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'
nest_asyncio.apply()

client = OpenAI()

QA_SYSTEM_PROMPT = """
    You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.\n
    Your goal is to provide step-by-step instructions and clear explanations to ensure users can understand and implement solutions easily.\n
    Always answer the query using the provided context information, 
    and not prior knowledge.\n
    Response should be thorough and fully answer all parts of the user's question.\n\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.\n
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.\m
    3. USE PLAIN ENGLISH WITHOUT TECHNICAL JARGON, catering to users who may not have a deep technical background.
    4. Do not justify your answers.
    5. Do not restate questions or suggestions in your answer.
    6. Do not include extraneous symbols, tags, or prefixes.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and no prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)

db = lancedb.connect("./lancedb_new")

# table = db.open_table("docs_OpenAI_hierarchical")
table = db.open_table("docs_OpenAI")
Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-large")
storage_context = StorageContext.from_defaults(persist_dir="./storage_new_OpenAI")

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)

base_retriever = index.as_retriever(similarity_top_k=30)


df = pd.read_excel("testsets/radiantlogic_cross.xlsx")
print(df)
output_cross = []
output_both = []

for i, question in enumerate(df['question']):
    print("Question " + str(i) + ": " + question)
    nodes = base_retriever.retrieve(question)
    reranked_nodes = reranker.postprocess_nodes(nodes, query_str=question)[:5]
    # chunks = [node.text for node in reranked_nodes]
    final_nodes = reranker2.postprocess_nodes(reranked_nodes, query_str=question)
    chunks2 = [node.text for node in final_nodes]

    # prompt = QA_USER_PROMPT.format(context_str=chunks, query_str=question)
    # response = client.chat.completions.create(
    #     model="gpt-4o",
    #     messages=[
    #         {"role": "system", "content": QA_SYSTEM_PROMPT},
    #         {"role": "user", "content": prompt}
    #     ]
    # )
    # answer = response.choices[0].message.content
    # output_cross.append(answer)

    prompt2 = QA_USER_PROMPT.format(context_str=chunks2, query_str=question)
    response2 = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": QA_SYSTEM_PROMPT},
            {"role": "user", "content": prompt2}
        ]
    )
    answer2 = response2.choices[0].message.content
    output_both.append(answer2)

# df['output_cross'] = output_cross
# df.to_excel("testsets/radiantlogic_cross.xlsx", index=False)
df['output_both'] = output_both
df.to_excel("testsets/radiantlogic_updated.xlsx", index=False)

# with open("my_qa_pairs.json", 'r') as file:
#     data = json.load(file)
#     for entry in data:
#         if "answer" in entry:
#             continue
#         question = entry['question']
#         context = entry['context']
#         prompt = QA_USER_PROMPT.format(context_str=context, query_str=question)
#         response = client.chat.completions.create(
#             model="gpt-4o",
#             messages=[
#                 {"role": "system", "content": QA_SYSTEM_PROMPT},
#                 {"role": "user", "content": prompt}
#             ]
#         )

#         answer = response.choices[0].message.content
#         entry['answer'] = answer

# with open('my_qa_pairs.json', 'w') as file:
    # json.dump(data, file, indent=4) 