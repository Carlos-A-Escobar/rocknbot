import os
import lancedb
import time
import numpy as np
# from gliner import GLiNER
from llama_index.core import VectorStoreIndex
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.postprocessor.colbert_rerank import ColbertRerank
import nest_asyncio

nest_asyncio.apply()

os.environ["OPENAI_API_KEY"] = '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'
OPENAI_API_KEY = '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'

reranker = SentenceTransformerRerank(top_n=40, model="cross-encoder/ms-marco-MiniLM-L-12-v2")
reranker2 = ColbertRerank(top_n=40, model="colbert-ir/colbertv2.0", tokenizer="colbert-ir/colbertv2.0", keep_retrieval_score=True)

import pandas as pd
from datasets import load_dataset
from tqdm import tqdm

def get_nodes(retriever, question):
        nodes = retriever.retrieve(question)

        first_half = nodes[:40]
        second_half = nodes[40:]
        reranked_nodes = reranker.postprocess_nodes(first_half, query_str=question)

        split1 = reranked_nodes[:5]
        split2 = reranked_nodes[5:]
        reranked_nodes2 = reranker2.postprocess_nodes(split1, query_str=question)
        combined_nodes = reranked_nodes2 + split2
        final_nodes = combined_nodes + second_half

        # final_nodes = reranked_nodes + second_half
        return final_nodes

# Load the SQuAD v2 validation dataset
squad_dev = load_dataset('squad_v2', split='validation')

# Convert the dataset to a DataFrame
squad_data = []
for row in tqdm(squad_dev):
    squad_df = squad_data.append({
        'question': row['question'],
        'context': row['context'],
        'id': row['id']
    })

squad_df = pd.DataFrame(squad_data)

# Drop duplicate contexts and modify IDs
no_dupe = squad_df.drop_duplicates(subset='context', keep='first')
no_dupe = no_dupe.drop(columns=['question'])
no_dupe['id'] = no_dupe['id'] + 'con'

# Merge the modified DataFrame with the original
squad_df = squad_df.merge(no_dupe, how='inner', on='context')

# Create the IR queries and corpus
ir_queries = {row['id_x']: row['question'] for i, row in squad_df.iterrows()}
ir_corpus = {row['id_y']: row['context'] for i, row in squad_df.iterrows()}

# Create the relevant docs mapping
ir_relevant_docs = {row['id_x']: row['id_y'] for _, row in squad_df.iterrows()}

ir_queries_subset = dict(list(ir_queries.items())[:250])



Settings.embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en-v1.5")
# Settings.embed_model = OpenAIEmbedding(model='text-embedding-3-large')
table_name = "BGE"
db = lancedb.connect("lancedb_SQUAD")
table = db.open_table(table_name)

vector_store = LanceDBVectorStore.from_table(table)
index = VectorStoreIndex.from_vector_store(vector_store)
retriever = index.as_retriever(similarity_top_k=100)


a = retriever.retrieve('a')
rank = 0
reciprocal_rank = 0
total_time = 0
num_questions = 0
num_found = 0
map_5 = 0
map_10 = 0
map_20 = 0
ndcg_5 = 0
ndcg_10 = 0
ndcg_20 = 0

for index, id in enumerate(ir_queries_subset):
    question = ir_queries[id]

    start_time = time.time()
    # nodes = retriever.retrieve(question)
    nodes = get_nodes(retriever, question)
    end_time = time.time()
    total_time += (end_time - start_time)

    correct_context_id = ir_relevant_docs[id]
    
    if nodes:
        num_questions += 1
        for i, node in enumerate(nodes):
            node_id = node.id_
            if node_id == correct_context_id:
                num_found += 1
                this_rank = i + 1
                rank += this_rank
                reciprocal_rank += 1 / this_rank
                print(f"Rank: {this_rank}, Node ID: {id}, Question Number: {index + 1}")

                ap = 1
                ndcg = (1.0 / np.log2(this_rank + 1))

                if this_rank <= 20:
                    map_20 += ap
                    ndcg_20 += ndcg
                if this_rank <= 10:
                    map_10 += ap
                    ndcg_10 += ndcg
                if this_rank <= 5:
                    map_5 += ap
                    ndcg_5 += ndcg
                break

# Calculate the global average rank and average reciprocal rank
print("rank: " + str(rank))
print("reciprocal rank: " + str(reciprocal_rank))
print("number of questions: " + str(num_questions))
avg_rank = rank / num_questions if num_questions > 0 else 0
avg_reciprocal_rank = reciprocal_rank / num_questions if num_questions > 0 else 0

map_5 = (map_5 / num_questions)
map_10 = (map_10 / num_questions)
map_20 = (map_20 / num_questions)
ndcg_5 = (ndcg_5 / num_questions)
ndcg_10 = (ndcg_10 / num_questions)
ndcg_20 = (ndcg_20 / num_questions)


with open('results.txt', 'a') as file:
    file.write(table_name + "_Average_Rank: " + str(avg_rank) + "\n")
    file.write(table_name + "_Reciprocal_Rank: " + str(avg_reciprocal_rank) + "\n")
    file.write(table_name + "_Time_Elapsed: " + str(total_time) + "\n")
    file.write(table_name + "_MAP@5: " + str(map_5) + "\n")
    file.write(table_name + "_MAP@10: " + str(map_10) + "\n")
    file.write(table_name + "_MAP@20: " + str(map_20) + "\n")
    file.write(table_name + "_NDCG@5: " + str(ndcg_5) + "\n")
    file.write(table_name + "_NDCG@10: " + str(ndcg_10) + "\n")
    file.write(table_name + "_NDCG@20: " + str(ndcg_20) + "\n\n\n")

    