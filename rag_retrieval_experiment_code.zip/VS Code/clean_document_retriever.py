import json
import warnings
import lancedb
from lancedb.rerankers import LinearCombinationReranker
from llama_index.core import Document
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import StorageContext
from llama_index.llms.openai import OpenAI as OpenAI_Llama
from llama_index.core.retrievers.auto_merging_retriever import AutoMergingRetriever
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings, VectorStoreIndex
from llama_index.vector_stores.lancedb import LanceDBVectorStore
from llama_index.core.postprocessor import SentenceTransformerRerank
from openai import OpenAI
from dotenv import dotenv_values
from corrective_rag_pack.llama_index.packs.corrective_rag.base import CorrectiveRAGPack

warnings.filterwarnings("ignore", category=FutureWarning)

RELEVANCY_PROMPT = """

You are comparing a reference text to a question and trying to determine if the reference text
contains information relevant to answering the question. You must determine whether the Reference text
contains information that can help answer the Question. First, write out in a step by step manner
an EXPLANATION to show how to arrive at the correct answer. Avoid simply stating the correct answer
at the outset. Your response LABEL must be single word, either "relevant" or "unrelated", and
should not contain any text or characters aside from that word. "unrelated" means that the
reference text does not help answer to the Question. "relevant" means the reference text directly
answers the question without the use of any other external information. EXPLANATION should be clear, but kept short. 
REMEMBER TO INCLUDE whether the reference text is "relevant" or "unrelated." 
DO NOT USE "*" characters in your response. DO NOT write any "\\" or "'" characters when labeling.

Example response:

EXPLANATION: An explanation of your reasoning for why the label is "relevant"
LABEL: relevant

Another example response:
EXPLANATION: An explanation of your reasoning for why the label is "unrelated"
LABEL: unrelated
"""

QUERY_EXPANSION_PROMPT_RL = """
You are an experienced RadiantLogic customer support specialist, trained in assisting end-users with product inquiries, usage guidance, and setup assistance.
Your task is to generate five different versions of the given user question to retrieve relevant documents from a vector database. 
By generating multiple perspectives on the user question, your goal is to help the user overcome some of the limitations of the distance-based similarity search. 
Provide these alternative questions seperated by a new line. DO NOT number or hyphenate the questions.
"""

QUERY_EXPANSION_PROMPT_RCF = """
You are an expert on the Lexus RC F, trained in assisting end-users with any inquiries about the car.
Your task is to generate five different versions of the given user question to retrieve relevant documents from a vector database. 
By generating multiple perspectives on the user question, your goal is to help the user overcome some of the limitations of the distance-based similarity search. 
Provide these alternative questions seperated by a new line. DO NOT number or hyphenate the questions.
"""

QA_SYSTEM_PROMPT = """
    You are an expert Q&A system that is trusted around the world.\n
    Always answer the query using the provided context information, 
    and not prior knowledge.\n
    Response should be concise. If it can be answered in one sentence, 
    then it should be answered in one sentence.\n
    Some rules to follow:\n
    1. Never directly reference the given context in your answer.\n
    2. Avoid statements like 'Based on the context, ...' or 
    'The context information ...' or anything along those lines.
"""

QA_USER_PROMPT = """
    Context information is below.\n
    ---------------------\n
    {context_str}\n
    ---------------------\n
    Given the context information and not prior knowledge, 
    answer the query.\n
    Query: {query_str}\n
    Answer: 
"""

class DocumentRetriever:
    def __init__(self, storage_path):

        rag_env = dotenv_values("rag.env")
        OPENAI_API_KEY = rag_env["OPENAI_API_KEY"]
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.embedding_function = OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY, model_name="text-embedding-ada-002")
        Settings.llm = OpenAI_Llama(model="gpt-3.5-turbo")
        Settings.embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-large-en-v1.5")
        # self.storage_context = StorageContext.from_defaults(persist_dir=storage_path)
        # self.index = load_index_from_storage(storage_context=self.storage_context, embed_model=self.embed_model)

        db = lancedb.connect(uri="./lancedb")
        table = db.open_table("BGE_Lexus")
        reranker = LinearCombinationReranker()
        vector_store = LanceDBVectorStore.from_table(table)
        vector_store._add_reranker(reranker=reranker)
        index = VectorStoreIndex.from_vector_store(vector_store=vector_store)
        base_retriever = index.as_retriever(similarity_top_k=10)
        
        storage_context = StorageContext.from_defaults(persist_dir=storage_path)

        self.auto_merging_retriever_vector = AutoMergingRetriever(base_retriever, storage_context)
        self.cross_reranker = SentenceTransformerRerank(top_n=6, model="cross-encoder/ms-marco-MiniLM-L-6-v2")
        self.input_questions_file_path = "./input/syntheticQuestions2.txt"
        self.correct = 0
        self.question = 1

    def get_answer(self, query):
        expanded_query = self._openai_generate_response(QUERY_EXPANSION_PROMPT_RCF, "gpt-3.5-turbo", question=query, max_tokens=100)
        joint_query = query + " " + expanded_query

        auto_nodes = self.auto_merging_retriever_vector.retrieve(joint_query)

        cross_nodes = self.cross_reranker.postprocess_nodes(nodes=auto_nodes, query_str=query)[:3]
        documents = [Document(text=node.text) for node in cross_nodes]
        corrective_rag = CorrectiveRAGPack(documents, "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")
        return corrective_rag.run(cross_nodes, query, similarity_top_k=3)

    def _evaluate_questions(self, questions):
        for question in questions:
            print(f"Working on Question: " + str(self.question))
            self.question += 1
            return self.get_answer(question)

    def process_queries_from_file(self):
        with open(self.input_questions_file_path, 'r') as file:
            questions = [line.strip() for line in file if line.strip()]
        return self._evaluate_questions(questions)

    def process_query_from_user_input(self):
        question = input("Please enter your question: ")
        answer = self._evaluate_questions([question])[1]
        print("Question: " + question)
        print("Answer: " + answer)
    
    def process_queries_from_json(self):
        with open("synthetic_data/8Q.json", 'r') as file:
            synthetic_data = json.load(file)
        for entry in synthetic_data:
            if entry['actual_output'] is None:
                response = self._evaluate_questions([entry['input']])
                entry['actual_output'] = response

        with open('synthetic_data/8Q.json', 'w') as result_file:
            json.dump(synthetic_data, result_file, indent=4)

    def _openai_generate_response(self, system_prompt, model, question=None, reference=None, max_tokens=None, user_prompt=None):
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        if user_prompt is None:
            if question is not None:
                messages.append({"role": "user", "content": f"[Question]: {question}"})
            if reference is not None:
                messages.append({"role": "user", "content": f"[Reference text]: {reference}"})
        else:
            messages.append({"role": "user", "content": f"{user_prompt}"})
            
        params = {
            "model": model,
            "messages": messages
        }
        
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        
        response = self.client.chat.completions.create(**params)
        result = response.choices[0].message.content
        return result

def main():
    storage_path = "./BGE_Lexus_Metadata"
    
    retriever = DocumentRetriever(storage_path)

    print("Choose an option:")
    print("1. Evaluate from a file")
    print("2. Evaluate from user input")
    print("3. Evaluate from a json")
    option = input("Enter your choice (1 2 3): ")

    if option == "1":
        retriever.process_queries_from_file()
    elif option == "2":
        retriever.process_query_from_user_input()
    elif option == "3":
        retriever.process_queries_from_json()
    else:
        print("Invalid option. Please choose either 1 or 2.")

if __name__ == "__main__":
    main()