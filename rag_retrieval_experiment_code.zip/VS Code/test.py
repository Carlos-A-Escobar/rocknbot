import boto3
from botocore.exceptions import ClientError

# Create a Bedrock Runtime client in the AWS Region you want to use.
client = boto3.client("bedrock-runtime", region_name="us-west-2", aws_access_key_id='AKIA2QETGWXF2YG2MP2G', aws_secret_access_key='A9RHHH2Ws+0WhC2BNFERbihkvGzwzLuBJTQCsOhq')

# Set the model ID, e.g., Llama 3 8b Instruct.
model_id = "meta.llama3-8b-instruct-v1:0"

# Start a conversation with the user message.
user_message = "What is 2 + 5"
conversation = [
    {
        "role": "user",
        "content": [{"text": "what is your favorite treat, pick only one"}],
    }
]

try:
    # Send the message to the model, using a basic inference configuration.
    response = client.converse(
        modelId=model_id,
        messages=conversation,
        system = [{"text": "Mention ice cream in your response."}],
        inferenceConfig={"maxTokens": 512, "temperature": 0.5, "topP": 0.9},
    )

    # Extract and print the response text.
    response_text = response["output"]["message"]["content"][0]["text"]
    print(response_text)

except (ClientError, Exception) as e:
    print(f"ERROR: Can't invoke '{model_id}'. Reason: {e}")
    exit(1)